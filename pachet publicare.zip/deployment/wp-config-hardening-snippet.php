<?php
/**
 * Integrați aceste setări în wp-config.php existent, fără să înlocuiți credențialele sau sărurile.
 * Snippet-ul nu este un wp-config.php complet și nu conține secrete.
 */
if (!defined('WP_DEBUG')) { define('WP_DEBUG', false); }
if (!defined('WP_DEBUG_DISPLAY')) { define('WP_DEBUG_DISPLAY', false); }
if (!defined('WP_DEBUG_LOG')) { define('WP_DEBUG_LOG', false); }
if (!defined('DISALLOW_FILE_EDIT')) { define('DISALLOW_FILE_EDIT', true); }
@ini_set('display_errors', '0');
