<?php
/**
 * The template for displaying the footer
 *
 * @package Primaria_Beba_Veche
 */
?>
    </div><!-- #content -->

    <footer class="pbv-footer" role="contentinfo">
        <div class="pbv-container">
            <div class="pbv-footer-grid">
                <!-- Col 1: About Institution -->
                <div class="pbv-footer-col">
                    <h3>Primăria Comunei Beba Veche</h3>
                    <p>Instituție publică în slujba cetățenilor comunei Beba Veche și a satelor aparținătoare Cherestur și Pordeanu, situată la punctul cel mai vestic al României (Triplex Confinium).</p>
                    <div class="pbv-footer-contact-item">
                        <span>📍</span>
                        <span>Comuna Beba Veche, Nr. 292, Județul Timiș, Cod Poștal 307035</span>
                    </div>
                    <div class="pbv-footer-contact-item">
                        <span>📞</span>
                        <span>Telefon / Fax: <a href="tel:0256385501">0256 385 501</a></span>
                    </div>
                    <div class="pbv-footer-contact-item">
                        <span>✉️</span>
                        <span>E-mail: <a href="mailto:secretariat@primariabebaveche.ro">secretariat@primariabebaveche.ro</a></span>
                    </div>
                </div>

                <!-- Col 2: Useful Sections -->
                <div class="pbv-footer-col">
                    <h3>Servicii & Informații</h3>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/monitorul-oficial-local/')); ?>">📜 Monitorul Oficial Local</a></li>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">📋 Formulare Tipizate</a></li>
                        <li><a href="<?php echo esc_url(home_url('/taxe-si-impozite/')); ?>">💳 Taxe și Impozite Locale</a></li>
                        <li><a href="<?php echo esc_url(home_url('/urbanism/')); ?>">🏗️ Urbanism & Amenajare</a></li>
                        <li><a href="<?php echo esc_url(home_url('/registru-agricol/')); ?>">🌾 Registrul Agricol</a></li>
                        <li><a href="<?php echo esc_url(home_url('/stare-civila/')); ?>">👥 Stare Civilă</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">📍 Program cu Publicul</a></li>
                    </ul>
                </div>

                <!-- Col 3: Useful Links -->
                <div class="pbv-footer-col">
                    <h3>Legături Utile</h3>
                    <ul>
                        <li><a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer">Ghișeul.ro - Plăți Online</a></li>
                        <li><a href="https://www.cjtimis.ro" target="_blank" rel="noopener noreferrer">Consiliul Județean Timiș</a></li>
                        <li><a href="https://tm.prefectura.mai.gov.ro" target="_blank" rel="noopener noreferrer">Prefectura Județului Timiș</a></li>
                        <li><a href="https://www.anaf.ro" target="_blank" rel="noopener noreferrer">ANAF</a></li>

                        <li><a href="https://anpc.ro" target="_blank" rel="noopener noreferrer">ANPC</a></li>
                    </ul>
                </div>

                <!-- Col 4: Working Hours & Digital Portal -->
                <div class="pbv-footer-col">
                    <h3>Program de Lucru</h3>
                    <p><strong>Luni – Joi:</strong> 08:00 – 16:00<br>
                    <strong>Vineri:</strong> 08:00 – 12:00</p>
                    <p style="margin-top:12px;"><strong>Casierie / Relații cu Publicul:</strong><br>
                    Luni – Joi: 08:30 – 15:30<br>
                    Vineri: 08:00 – 12:00</p>
                    <div style="margin-top:18px;">
                        <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" style="display:inline-block; background:#ffffff; padding:6px 12px; border-radius:6px;">
                            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo-ghiseul.svg'); ?>" alt="Ghișeul.ro" class="pbv-ghiseul-logo" width="104" height="26">
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Copyright -->
        <div class="pbv-footer-bottom">
            <div class="pbv-container">
                <div>
                    &copy; <?php echo date('Y'); ?> <strong>Primăria Comunei Beba Veche</strong>. Toate drepturile rezervate. Conform legislației privind transparența instituțională și protecția datelor.
                </div>
                <div style="display:flex; gap:16px;">
                    <a href="<?php echo esc_url(home_url('/politica-de-confidentialitate/')); ?>">Politica de Confidențialitate (GDPR)</a>
                    <a href="<?php echo esc_url(home_url('/termeni-si-conditii/')); ?>">Termeni și Condiții</a>
                </div>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
