<?php
/**
 * Functions and definitions for Primăria Comunei Beba Veche Theme
 *
 * @package Primaria_Beba_Veche
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!function_exists('pbv_setup')) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     */
    function pbv_setup() {
        // Make theme available for translation.
        load_theme_textdomain('primaria-beba-veche', get_template_directory() . '/languages');

        // Add default posts and comments RSS feed links to head.
        add_theme_support('automatic-feed-links');

        // Let WordPress manage the document title.
        add_theme_support('title-tag');

        // Enable support for Post Thumbnails on posts and pages.
        add_theme_support('post-thumbnails');

        // Register Menus
        register_nav_menus(array(
            'primary-menu' => esc_html__('Meniu Principal Header', 'primaria-beba-veche'),
            'footer-menu'  => esc_html__('Meniu Subsol', 'primaria-beba-veche'),
            'top-utility'  => esc_html__('Meniu Utilitar Bară Sus', 'primaria-beba-veche'),
        ));

        // Switch default core markup for search form, comment form, and comments to output valid HTML5.
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ));

        // Set up the WordPress core custom background feature.
        add_theme_support('custom-background', apply_filters('pbv_custom_background_args', array(
            'default-color' => 'f8fafc',
            'default-image' => '',
        )));

        // Add theme support for selective refresh for widgets.
        add_theme_support('customize-selective-refresh-widgets');

        // Add support for core custom logo.
        add_theme_support('custom-logo', array(
            'height'      => 120,
            'width'       => 120,
            'flex-width'  => true,
            'flex-height' => true,
        ));
    }
endif;
add_action('after_setup_theme', 'pbv_setup');

/**
 * Enqueue scripts and styles.
 */
function pbv_scripts() {
    wp_enqueue_style('pbv-style', get_stylesheet_uri(), array(), '1.1.0');
    wp_enqueue_script('pbv-main', get_template_directory_uri() . '/assets/js/main.js', array(), '1.1.0', true);
}
add_action('wp_enqueue_scripts', 'pbv_scripts');


/**
 * Theme Customizer Settings for Beba Veche
 */
function pbv_customize_register($wp_customize) {
    // Date de Contact Instituționale
    $wp_customize->add_section('pbv_contact_section', array(
        'title'    => __('Date de Contact Instituționale', 'primaria-beba-veche'),
        'priority' => 35,
    ));

    $wp_customize->add_setting('pbv_phone', array(
        'default'           => '0256 385 501',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('pbv_phone', array(
        'label'   => __('Telefon / Fax', 'primaria-beba-veche'),
        'section' => 'pbv_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('pbv_email', array(
        'default'           => 'secretariat@primariabebaveche.ro',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('pbv_email', array(
        'label'   => __('Email Oficial', 'primaria-beba-veche'),
        'section' => 'pbv_contact_section',
        'type'    => 'email',
    ));

    $wp_customize->add_setting('pbv_address', array(
        'default'           => 'Comuna Beba Veche, Nr. 292, Județul Timiș, Cod 307035',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('pbv_address', array(
        'label'   => __('Adresă Sediu', 'primaria-beba-veche'),
        'section' => 'pbv_contact_section',
        'type'    => 'text',
    ));
}
add_action('customize_register', 'pbv_customize_register');

/**
 * Legacy single-folder embed kept for backward compatibility.
 * The Monitorul Oficial Local page uses the CSV-backed [pbv_mol_browser] plugin shortcode.
 * Usage: [google_drive_mol folder_id="..."]
 */
function pbv_google_drive_mol_shortcode($atts) {
    $atts = shortcode_atts(array(
        'folder_id' => get_theme_mod('pbv_mol_drive_id', ''),
        'height'    => '720px',
    ), $atts, 'google_drive_mol');

    $folder_id = trim($atts['folder_id']);

    if (empty($folder_id)) {
        return '<div class="pbv-drive-placeholder">
            <div class="pbv-drive-placeholder-icon">📁</div>
            <h3>Widget Google Drive - Monitorul Oficial Local</h3>
            <p>Acest shortcode vechi afișează un singur folder. Pentru arhiva pe categorii și ani, folosiți pagina Monitorul Oficial Local și pluginul PBV.</p>
        </div>';
    }

    // Sanitize folder ID if full URL was provided
    if (preg_match('/folders\/([a-zA-Z0-9_-]+)/', $folder_id, $matches)) {
        $folder_id = $matches[1];
    }

    $iframe_url = 'https://drive.google.com/embeddedfolderview?id=' . esc_attr($folder_id) . '#list';

    return '<div class="pbv-drive-frame-wrapper" style="height:' . esc_attr($atts['height']) . ';">
        <iframe src="' . esc_url($iframe_url) . '" class="pbv-drive-frame" title="Monitorul Oficial Local - Google Drive" allowfullscreen></iframe>
    </div>';
}
add_shortcode('google_drive_mol', 'pbv_google_drive_mol_shortcode');

/**
 * Breadcrumb Helper Function
 */
function pbv_breadcrumbs() {
    if (is_front_page()) {
        return;
    }
    echo '<nav class="pbv-breadcrumbs" aria-label="Navigare pe site" style="font-size:13px; color:#64748b; margin-bottom:20px; display:flex; align-items:center; gap:8px;">';
    echo '<a href="' . esc_url(home_url('/')) . '" style="color:#19487e; font-weight:600;">Acasă</a>';
    echo '<span>/</span>';

    if (is_page()) {
        the_title('<span>', '</span>');
    } elseif (is_single()) {
        $cats = get_the_category();
        if ($cats) {
            echo '<a href="' . esc_url(get_category_link($cats[0]->term_id)) . '">' . esc_html($cats[0]->name) . '</a> <span>/</span> ';
        }
        the_title('<span>', '</span>');
    } elseif (is_category() || is_archive()) {
        echo '<span>' . single_cat_title('', false) . '</span>';
    } elseif (is_search()) {
        echo '<span>Rezultate căutare pentru: "' . esc_html(get_search_query()) . '"</span>';
    } elseif (is_404()) {
        echo '<span>Pagina nu a fost găsită (404)</span>';
    }
    echo '</nav>';
}

/**
 * Fallback primary navigation menu if no WP menu assigned yet
 */
function pbv_default_menu() {
    echo '<ul class="pbv-main-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '">Acasă</a></li>';
    echo '<li><a href="' . esc_url(home_url('/monitorul-oficial-local/')) . '">Monitorul Oficial Local</a></li>';
    echo '<li><a href="' . esc_url(home_url('/formulare/')) . '">Formulare</a></li>';
    echo '<li><a href="' . esc_url(home_url('/media/')) . '">Media</a></li>';
    echo '<li class="menu-item-has-children"><a href="' . esc_url(home_url('/despre-comuna/')) . '">Despre Comună</a>';
    echo '<ul class="sub-menu">';
    echo '<li><a href="' . esc_url(home_url('/prezentare-istoric/')) . '">Prezentare & Istoric</a></li>';
    echo '<li><a href="' . esc_url(home_url('/triplex-confinium/')) . '">Triplex Confinium</a></li>';
    echo '<li><a href="' . esc_url(home_url('/sate-apartinatoare/')) . '">Sate: Beba Veche, Cherestur, Pordeanu</a></li>';
    echo '</ul></li>';
    echo '<li class="menu-item-has-children"><a href="' . esc_url(home_url('/administratie/')) . '">Administrație</a>';
    echo '<ul class="sub-menu">';
    echo '<li><a href="' . esc_url(home_url('/conducere/')) . '">Primar & Conducere</a></li>';
    echo '<li><a href="' . esc_url(home_url('/consiliul-local/')) . '">Consiliul Local</a></li>';
    echo '<li><a href="' . esc_url(home_url('/transparenta/')) . '">Transparență Decizională</a></li>';
    echo '</ul></li>';
    echo '<li class="menu-item-has-children"><a href="' . esc_url(home_url('/servicii-cetateni/')) . '">Servicii Cetățeni</a>';
    echo '<ul class="sub-menu">';
    echo '<li><a href="' . esc_url(home_url('/taxe-si-impozite/')) . '">Taxe și Impozite</a></li>';
    echo '<li><a href="' . esc_url(home_url('/urbanism/')) . '">Urbanism & Cadastru</a></li>';
    echo '<li><a href="' . esc_url(home_url('/stare-civila/')) . '">Stare Civilă</a></li>';
    echo '<li><a href="' . esc_url(home_url('/registru-agricol/')) . '">Registrul Agricol</a></li>';
    echo '</ul></li>';
    echo '<li><a href="' . esc_url(home_url('/contact/')) . '">Contact</a></li>';
    echo '</ul>';
}
