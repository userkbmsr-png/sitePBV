<?php
/**
 * The header for Primăria Comunei Beba Veche theme
 *
 * @package Primaria_Beba_Veche
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php if (!get_option('site_icon')) : $pbv_icon_uploads = wp_upload_dir(); ?>
        <link rel="icon" href="<?php echo esc_url(trailingslashit($pbv_icon_uploads['baseurl']) . 'stema-color.jpg'); ?>" type="image/jpeg">
    <?php endif; ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <!-- Romanian Tricolor Line -->
    <div class="pbv-tricolor-line" aria-hidden="true">
        <div class="color-blue"></div>
        <div class="color-yellow"></div>
        <div class="color-red"></div>
    </div>

    <!-- Top Utility & Accessibility Bar -->
    <aside class="pbv-topbar" aria-label="Bara de utilități și rețele sociale">
        <div class="pbv-container">
            <div class="pbv-topbar-left">
                <span>📍 Sediu: Comuna Beba Veche nr. 292, Jud. Timiș</span>
                <span>📞 Tel: <a href="tel:0256385501">0256 385 501</a></span>
                <span>✉️ <a href="mailto:secretariat@primariabebaveche.ro">secretariat@primariabebaveche.ro</a></span>
            </div>
            <div class="pbv-topbar-right">
                <a class="pbv-facebook-link" href="https://www.facebook.com/p/Primaria-Beba-Veche-61558195855065/" target="_blank" rel="noopener noreferrer" aria-label="Pagina de Facebook a Primăriei Comunei Beba Veche" title="Facebook – Primăria Beba Veche"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M13.7 21v-8.2h2.8l.4-3.2h-3.2V7.5c0-.9.3-1.6 1.6-1.6H17V3.1c-.3 0-1.3-.1-2.5-.1-2.5 0-4.2 1.5-4.2 4.3v2.3H7.5v3.2h2.8V21h3.4z"/></svg></a>
                <div class="pbv-flags" role="group" aria-label="Drapelele României și Uniunii Europene">
                    <img class="pbv-flag" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/flag-ro.svg'); ?>" alt="Drapelul României" width="20" height="13">
                    <img class="pbv-flag" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/flag-eu.svg'); ?>" alt="Drapelul Uniunii Europene" width="20" height="13">
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Header -->
    <header class="pbv-header" role="banner">
        <div class="pbv-container">
            <div class="pbv-header-inner">
                <!-- Branding & Coat of Arms -->
                <a href="<?php echo esc_url(home_url('/')); ?>" class="pbv-branding" rel="home">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/stema-beba-veche.svg'); ?>" alt="Stema Comunei Beba Veche" class="pbv-logo-img">
                    <div>
                        <h1 class="pbv-site-title">Primăria Comunei Beba Veche</h1>
                        <div class="pbv-site-subtitle">
                            <span>Județul Timiș • România</span>
                            <span class="pbv-site-badge">Cel mai vestic punct al României</span>
                        </div>
                    </div>
                </a>

                <!-- Header Actions -->
                <div class="pbv-header-actions">
                    <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" class="pbv-btn pbv-btn-outline" title="Plătește taxe și impozite online prin Ghișeul.ro">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo-ghiseul.svg'); ?>" alt="Ghișeul.ro" class="pbv-ghiseul-logo" width="112" height="28">
                    </a>
                    <a href="<?php echo esc_url(home_url('/monitorul-oficial-local/')); ?>" class="pbv-btn pbv-btn-primary">
                        <span>📜</span> Monitorul Oficial
                    </a>
                </div>
            </div>
        </div>

        <!-- Main Navigation Bar -->
        <nav class="pbv-nav-bar" role="navigation" aria-label="Meniu principal">
            <div class="pbv-container">
                <div class="pbv-nav-inner">
                    <button class="pbv-mobile-toggle" aria-expanded="false" aria-label="Comută meniul de navigare">
                        ☰ Meniu
                    </button>

                    <?php
                    if (has_nav_menu('primary-menu')) {
                        wp_nav_menu(array(
                            'theme_location' => 'primary-menu',
                            'menu_class'     => 'pbv-main-menu',
                            'container'      => false,
                            'depth'          => 2,
                        ));
                    } else {
                        pbv_default_menu();
                    }
                    ?>
                </div>
            </div>
        </nav>
    </header>

    <div id="content" class="site-content">
