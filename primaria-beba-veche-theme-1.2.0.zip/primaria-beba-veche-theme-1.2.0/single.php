<?php
/**
 * The template for displaying a single post without a sidebar.
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <div class="pbv-single-meta"><span>Publicat la: <?php echo esc_html(get_the_date('j F Y')); ?></span><span>Autor: <?php the_author(); ?></span></div>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('pbv-page-content'); ?>>
                <?php if (has_post_thumbnail()) : ?><div class="pbv-single-thumbnail"><?php the_post_thumbnail('large'); ?></div><?php endif; ?>
                <?php the_content(); ?>
                <div class="pbv-single-back"><a href="<?php echo esc_url(home_url('/anunturi/')); ?>" class="pbv-btn pbv-btn-outline">&larr; Înapoi la toate anunțurile</a></div>
            </article>
        <?php endwhile; ?>
    </div>
</main>
<?php get_footer(); ?>
