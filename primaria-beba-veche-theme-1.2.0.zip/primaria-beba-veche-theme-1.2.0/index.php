<?php
/**
 * The main template file
 *
 * @package Primaria_Beba_Veche
 */

get_header();
?>

<main id="primary" class="site-main">
    <div style="background-color: var(--pbv-blue-subtle); border-bottom: 1px solid var(--pbv-border); padding: 25px 0;">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 style="font-family: var(--pbv-font-heading); font-size: 30px; font-weight: 800; color: var(--pbv-blue-dark);">
                Noutăți & Anunțuri Publice
            </h1>
        </div>
    </div>

    <div class="pbv-container" style="padding-top: 35px; padding-bottom: 60px;">
        <div class="pbv-news-grid">
            <?php
            if (have_posts()) :
                while (have_posts()) : the_post();
            ?>
                <article class="pbv-news-card">
                    <div class="pbv-news-body">
                        <div class="pbv-news-meta">
                            <span class="pbv-news-cat"><?php $c = get_the_category(); echo $c ? esc_html($c[0]->name) : 'Noutăți'; ?></span>
                            <time datetime="<?php echo get_the_date('c'); ?>"><?php echo get_the_date('j F Y'); ?></time>
                        </div>
                        <h2 class="pbv-news-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="pbv-news-excerpt">
                            <?php echo wp_trim_words(get_the_excerpt(), 24, '...'); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Citește tot &rarr;</a>
                    </div>
                </article>
            <?php
                endwhile;
                the_posts_pagination();
            else :
                echo '<p>Nu au fost găsite articole.</p>';
            endif;
            ?>
        </div>
    </div>
</main>

<?php
get_footer();
