<?php
/**
 * The template for displaying search results pages
 *
 * @package Primaria_Beba_Veche
 */

get_header();
?>

<main id="primary" class="site-main">
    <div style="background-color: var(--pbv-blue-subtle); border-bottom: 1px solid var(--pbv-border); padding: 25px 0;">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 style="font-family: var(--pbv-font-heading); font-size: 28px; font-weight: 800; color: var(--pbv-blue-dark);">
                Rezultate căutare pentru: <span style="color:var(--pbv-gold);">&ldquo;<?php echo get_search_query(); ?>&rdquo;</span>
            </h1>
        </div>
    </div>

    <div class="pbv-container" style="padding-top: 35px; padding-bottom: 60px;">
        <div class="pbv-news-grid">
            <?php
            if (have_posts()) :
                while (have_posts()) : the_post();
            ?>
                <article class="pbv-news-card">
                    <div class="pbv-news-body">
                        <h2 class="pbv-news-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h2>
                        <div class="pbv-news-excerpt">
                            <?php the_excerpt(); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Vezi pagina &rarr;</a>
                    </div>
                </article>
            <?php
                endwhile;
                the_posts_pagination();
            else :
            ?>
                <div style="background:#ffffff; padding:40px; border-radius:var(--pbv-radius); border:1px solid var(--pbv-border); text-align:center;">
                    <p style="font-size:16px; color:var(--pbv-text-muted); margin-bottom:20px;">
                        Nu a fost găsit niciun rezultat pentru termenul căutat. Vă rugăm să încercați alți termeni de căutare.
                    </p>
                    <a href="<?php echo esc_url(home_url('/formulare/')); ?>" class="pbv-btn pbv-btn-primary">
                        Vezi lista de formulare tipizate
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php
get_footer();
