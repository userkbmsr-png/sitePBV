<?php
/**
 * Template Name: Formulare administrabile
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <p class="pbv-page-intro">Descărcați formularele necesare pentru solicitările adresate Primăriei Comunei Beba Veche. Un document poate fi asociat mai multor compartimente.</p>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php if (shortcode_exists('pbv_formulare')) : ?>
            <?php echo do_shortcode('[pbv_formulare]'); ?>
        <?php else : ?>
            <p class="pbv-announcements-empty">Activați pluginul „PBV – Formulare și Monitorul Oficial Local” pentru a afișa catalogul administrabil.</p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
