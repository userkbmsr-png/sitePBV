<?php
/**
 * All announcements: published posts in reverse chronological order.
 * @package Primaria_Beba_Veche
 */
get_header();
$paged = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
$announcements = new WP_Query(array(
    'post_type' => 'post',
    'post_status' => 'publish',
    'posts_per_page' => 12,
    'paged' => $paged,
    'orderby' => 'date',
    'order' => 'DESC',
    'ignore_sticky_posts' => true,
));
?>
<main id="primary" class="site-main pbv-all-announcements">
    <div class="pbv-page-heading"><div class="pbv-container">
        <?php pbv_breadcrumbs(); ?>
        <h1 class="pbv-page-title">Toate Anunțurile</h1>
        <p class="pbv-page-intro">Toate postările publicate, de la cele mai noi la cele mai vechi. Anunțurile etichetate „important” sunt evidențiate.</p>
    </div></div>
    <div class="pbv-container pbv-page-content-wrap">
        <div class="pbv-news-grid">
        <?php if ($announcements->have_posts()) : while ($announcements->have_posts()) : $announcements->the_post();
            $cats = get_the_category();
            $cat_name = !empty($cats) ? $cats[0]->name : 'Anunț';
            $is_important = has_tag('important');
        ?>
            <article <?php post_class('pbv-news-card' . ($is_important ? ' is-important' : '')); ?>>
                <div class="pbv-news-body">
                    <?php if ($is_important) : ?><span class="pbv-news-important">Important</span><?php endif; ?>
                    <div class="pbv-news-meta"><span class="pbv-news-cat"><?php echo esc_html($cat_name); ?></span><time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('j F Y')); ?></time></div>
                    <h2 class="pbv-news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="pbv-news-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 28, '…')); ?></div>
                    <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Citește anunțul &rarr;</a>
                </div>
            </article>
        <?php endwhile; else : ?>
            <p class="pbv-announcements-empty">Nu există încă anunțuri publicate.</p>
        <?php endif; ?>
        </div>
        <?php if ($announcements->max_num_pages > 1) : ?>
            <nav class="pbv-all-announcements-pagination" aria-label="Paginare anunțuri">
                <?php echo wp_kses_post(paginate_links(array(
                    'base' => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                    'format' => '?paged=%#%',
                    'current' => $paged,
                    'total' => (int) $announcements->max_num_pages,
                    'mid_size' => 2,
                    'prev_text' => '‹ Înapoi',
                    'next_text' => 'Înainte ›',
                ))); ?>
            </nav>
        <?php endif; ?>
        <?php wp_reset_postdata(); ?>
    </div>
</main>
<?php get_footer(); ?>
