<?php
/**
 * The template for displaying the front page
 *
 * @package Primaria_Beba_Veche
 */

get_header();
?>

<main id="primary" class="site-main">
    <!-- Hero Section -->
    <section class="pbv-hero" aria-label="Prezentare Beba Veche">
        <div class="pbv-container">
            <div class="pbv-hero-content">
                <div class="pbv-hero-badge">
                    <span>🇷🇴</span> Cel mai vestic punct al României • Triplex Confinium
                </div>
                <h1 class="pbv-hero-title">
                    Bun venit pe portalul oficial al Comunei Beba Veche
                </h1>
                <p class="pbv-hero-desc">
                    Misiunea administrației locale este de a stimula și sprijini prosperitatea comunei Beba Veche și a satelor aparținătoare <strong>Cherestur</strong> și <strong>Pordeanu</strong>, oferind cetățenilor servicii publice moderne, transparente și accesibile.
                </p>
                <div class="pbv-hero-cta">
                    <a href="<?php echo esc_url(home_url('/monitorul-oficial-local/')); ?>" class="pbv-btn pbv-btn-accent">
                        <span>📜</span> Monitorul Oficial Local
                    </a>
                    <a href="<?php echo esc_url(home_url('/formulare/')); ?>" class="pbv-btn pbv-btn-primary" style="background:#ffffff; color:var(--pbv-blue-dark);">
                        <span>📋</span> Formulare Tipizate
                    </a>
                    <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" class="pbv-btn pbv-btn-outline" style="border-color:rgba(255,255,255,0.4); color:#ffffff;">
                        <span>💳</span> Plăți Ghișeul.ro
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Access Cards (4 Pillars) -->
    <div class="pbv-container">
        <div class="pbv-quick-grid">
            <a href="<?php echo esc_url(home_url('/monitorul-oficial-local/')); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">📜</div>
                <h3 class="pbv-quick-title">Monitorul Oficial Local</h3>
                <p class="pbv-quick-text">Registrul actelor administrative, Hotărârile Consiliului Local și Dispozițiile Primarului conectate prin Google Drive.</p>
                <span class="pbv-quick-link">Accesează Registrul &rarr;</span>
            </a>

            <a href="<?php echo esc_url(home_url('/formulare/')); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">📋</div>
                <h3 class="pbv-quick-title">Formulare & Cereri Tipizate</h3>
                <p class="pbv-quick-text">Peste 35 de modele de cereri și declarații pentru Urbanism, Taxe, Registrul Agricol și Stare Civilă gata de descărcat.</p>
                <span class="pbv-quick-link">Vezi Formularele &rarr;</span>
            </a>

            <a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer" class="pbv-quick-card">
                <div class="pbv-quick-icon">💳</div>
                <h3 class="pbv-quick-title">Plăți Online Ghișeul.ro</h3>
                <p class="pbv-quick-text">Achitați impozitele și taxele locale pe clădiri, terenuri și vehicule simplu, rapid și fără comisioane bancare.</p>
                <span class="pbv-quick-link">Plătește pe Ghișeul.ro &rarr;</span>
            </a>

            <a href="<?php echo esc_url(home_url('/conducere/')); ?>" class="pbv-quick-card">
                <div class="pbv-quick-icon">🏛️</div>
                <h3 class="pbv-quick-title">Conducere & Consiliul Local</h3>
                <p class="pbv-quick-text">Informații despre executivul primăriei, membrii Consiliului Local Beba Veche, comisii și transparență decizională.</p>
                <span class="pbv-quick-link">Află Detalii &rarr;</span>
            </a>
        </div>
    </div>

    <!-- Announcements & News Section -->
    <section class="pbv-section">
        <div class="pbv-container">
            <div class="pbv-section-head pbv-section-head--subtitle">
                <div>
                    <h2 class="pbv-section-title">Anunțuri Recente & Noutăți</h2>
                    <p class="pbv-section-subtitle">Comunicate oficiale, dezbateri publice și evenimente din Comuna Beba Veche</p>
                </div>
                <a href="<?php echo esc_url(home_url('/anunturi/')); ?>" class="pbv-btn pbv-btn-outline" style="font-size:13px;">
                    Toate Anunțurile &rarr;
                </a>
            </div>

            <div class="pbv-news-grid">
                <?php
                $sticky_ids = array_map('absint', (array) get_option('sticky_posts', array()));
                $recent_posts = new WP_Query(array(
                    'post_type'           => 'post',
                    'post_status'         => 'publish',
                    'posts_per_page'      => 3,
                    'tag_slug__in'        => array('important'),
                    'post__in'            => $sticky_ids ? $sticky_ids : array(0),
                    'orderby'             => 'date',
                    'order'               => 'DESC',
                    'ignore_sticky_posts' => 1,
                ));

                if ($recent_posts->have_posts()) :
                    while ($recent_posts->have_posts()) : $recent_posts->the_post();
                        $cats = get_the_category();
                        $cat_name = !empty($cats) ? $cats[0]->name : 'Anunț Oficial';
                ?>
                    <article class="pbv-news-card is-important">
                        <div class="pbv-news-body">
                            <span class="pbv-news-important">Important</span>
                            <div class="pbv-news-meta">
                                <span class="pbv-news-cat"><?php echo esc_html($cat_name); ?></span>
                                <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('j F Y')); ?></time>
                            </div>
                            <h3 class="pbv-news-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="pbv-news-excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22, '…')); ?></div>
                            <a href="<?php the_permalink(); ?>" class="pbv-quick-link">Citește anunțul &rarr;</a>
                        </div>
                    </article>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                    <p class="pbv-announcements-empty">Nu există momentan anunțuri publicate care să fie simultan marcate ca sticky și etichetate „important”.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Services & Compartments Grid -->
    <section class="pbv-section" style="background-color: #ffffff; border-top: 1px solid var(--pbv-border); border-bottom: 1px solid var(--pbv-border);">
        <div class="pbv-container">
            <div class="pbv-section-head pbv-section-head--subtitle">
                <div>
                    <h2 class="pbv-section-title">Servicii pentru Cetățeni</h2>
                    <p class="pbv-section-subtitle">Ghidul compartimentelor din Primăria Beba Veche și procedurile administrative</p>
                </div>
            </div>

            <div class="pbv-services-grid">
                <div class="pbv-service-card">
                    <h3><span>🏗️</span> Urbanism & Amenajare</h3>
                    <p>Certificate de urbanism, autorizații de construire, avize de oportunitate, prelungiri și recepții lucrări.</p>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Formulare Urbanism &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/urbanism/')); ?>">Documente necesare autorizare &rarr;</a></li>
                    </ul>
                </div>

                <div class="pbv-service-card">
                    <h3><span>💳</span> Taxe și Impozite</h3>
                    <p>Stabilirea și încasarea impozitelor pe clădiri, terenuri intravilane/extravilane și autovehicule.</p>
                    <ul>
                        <li><a href="https://www.ghiseul.ro" target="_blank" rel="noopener noreferrer">Plată online Ghișeul.ro &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Declarații fiscale PF / PJ &rarr;</a></li>
                    </ul>
                </div>

                <div class="pbv-service-card">
                    <h3><span>🌾</span> Registrul Agricol</h3>
                    <p>Evidența gospodăriilor agricole, eliberarea adeverințelor APIA, atestate de producător și tranzacții terenuri (Legea 17/2014).</p>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Cerere Adeverință APIA &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Oferte vânzare teren agricol &rarr;</a></li>
                    </ul>
                </div>

                <div class="pbv-service-card">
                    <h3><span>👥</span> Stare Civilă</h3>
                    <p>Înregistrarea nașterilor, căsătoriilor, deceselor, transcrieri de acte din străinătate și divorțuri administrative.</p>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Cereri transcriere acte &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/stare-civila/')); ?>">Documente căsătorie &rarr;</a></li>
                    </ul>
                </div>

                <div class="pbv-service-card">
                    <h3><span>🤝</span> Asistență Socială</h3>
                    <p>Ajutoare de încălzire, alocații, indemnizații persoane cu dizabilități și sprijin pentru familii vulnerabile.</p>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/asistenta-sociala/')); ?>">Servicii sociale disponibile &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact asistent social &rarr;</a></li>
                    </ul>
                </div>

                <div class="pbv-service-card">
                    <h3><span>📬</span> Registratură & Relații</h3>
                    <p>Preluarea cererilor, petițiilor, solicitărilor pe Legea nr. 544/2001 și audiențe cu conducerea primăriei.</p>
                    <ul>
                        <li><a href="<?php echo esc_url(home_url('/formulare/')); ?>">Model cerere tipizată &rarr;</a></li>
                        <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Program audiențe &rarr;</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Highlight Section: Westernmost Point & Triplex Confinium -->
    <div class="pbv-container">
        <div class="pbv-highlight-box">
            <div>
                <h2>Beba Veche – Cel mai vestic punct al României</h2>
                <p>
                    Așezată în câmpia roditoare a Banatului, la confluența a trei culturi și popoare, Comuna Beba Veche este străjuită de monumentul istoric <strong>Triplex Confinium</strong>, locul unic unde România se întâlnește cu Ungaria și Serbia.
                </p>
                <p>
                    Alături de satele <strong>Cherestur</strong> și <strong>Pordeanu</strong>, comunitatea noastră păstrează vie tradiția conviețuirii armonioase, îmbinată cu dorința fermă de modernizare europeană și dezvoltare economică durabilă.
                </p>
                <a href="<?php echo esc_url(home_url('/despre-comuna/')); ?>" class="pbv-btn pbv-btn-accent" style="display:inline-block;">
                    Descoperă Istoria & Obiectivele Comunei &rarr;
                </a>
            </div>
            <div class="pbv-highlight-stats">
                <div class="pbv-stat-card">
                    <div class="pbv-stat-val">20°15'44" E</div>
                    <div class="pbv-stat-label">Longitudine (Punct Vestic)</div>
                </div>
                <div class="pbv-stat-card">
                    <div class="pbv-stat-val">3</div>
                    <div class="pbv-stat-label">Sate componente</div>
                </div>
                <div class="pbv-stat-card">
                    <div class="pbv-stat-val">1920</div>
                    <div class="pbv-stat-label">Triplex Confinium</div>
                </div>
                <div class="pbv-stat-card">
                    <div class="pbv-stat-val">307035</div>
                    <div class="pbv-stat-label">Cod Poștal Oficial</div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
get_footer();
