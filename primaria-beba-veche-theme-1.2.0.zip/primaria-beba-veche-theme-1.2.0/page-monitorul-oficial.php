<?php
/**
 * Template Name: Monitorul Oficial Local – arhivă Google Drive
 * @package Primaria_Beba_Veche
 */
get_header();
?>
<main id="primary" class="site-main">
    <div class="pbv-page-heading">
        <div class="pbv-container">
            <?php pbv_breadcrumbs(); ?>
            <h1 class="pbv-page-title"><?php the_title(); ?></h1>
            <p class="pbv-page-intro">Registrul documentelor oficiale ale Comunei Beba Veche, organizat pe categorii, ani și subfoldere.</p>
        </div>
    </div>
    <div class="pbv-container pbv-page-content-wrap">
        <?php if (shortcode_exists('pbv_mol_browser')) : ?>
            <?php echo do_shortcode('[pbv_mol_browser]'); ?>
        <?php else : ?>
            <p class="pbv-announcements-empty">Activați pluginul „PBV – Formulare și Monitorul Oficial Local” pentru a afișa navigarea arhivei.</p>
        <?php endif; ?>
    </div>
</main>
<?php get_footer(); ?>
