<?php
/**
 * Plugin Name: PBV – Formulare și Monitorul Oficial Local
 * Description: Formulare, catalogul Google Drive pentru Monitorul Oficial Local și galerie foto-video.
 * Version: 1.4.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Text Domain: pbv-site-enhancements
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . 'includes/class-pbv-drive-catalog-manager.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-pbv-media-gallery.php';

final class PBV_Site_Enhancements {
    private const VERSION = '1.4.0';
    private const CATALOG_RELATIVE_PATH = 'formulare/catalog-formulare.json';
    private const DRIVE_DATA_FILE = 'data/google-drive-folders.json';

    private $departments = array(
        'urbanism' => 'Urbanism & Cadastru',
        'taxe-si-impozite' => 'Taxe & Impozite',
        'stare-civila' => 'Stare Civilă',
        'registru-agricol' => 'Registru Agricol',
        'diverse-si-544' => 'Diverse & Legea 544',
    );

    public function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_post_pbv_forms_add', array($this, 'handle_form_add'));
        add_action('admin_post_pbv_forms_delete', array($this, 'handle_form_delete'));
        add_shortcode('pbv_formulare', array($this, 'forms_shortcode'));
        add_shortcode('pbv_mol_browser', array($this, 'mol_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_public_assets'));
    }

    public static function activate() {
        $pages = array(
            array('slug' => 'formulare', 'title' => 'Formulare'),
            array('slug' => 'monitorul-oficial-local', 'title' => 'Monitorul Oficial Local'),
            array('slug' => 'anunturi', 'title' => 'Toate Anunțurile'),
            array('slug' => 'media', 'title' => 'Media', 'content' => '[pbv_media_gallery]'),
        );
        foreach ($pages as $page) {
            if (get_page_by_path($page['slug'], OBJECT, 'page')) {
                continue;
            }
            wp_insert_post(array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_title' => $page['title'],
                'post_name' => $page['slug'],
                'post_content' => isset($page['content']) ? $page['content'] : '',
            ));
        }
    }

    public function admin_menu() {
        add_menu_page(
            'Administrare formulare',
            'Formulare',
            'manage_options',
            'pbv-formulare',
            array($this, 'render_admin_page'),
            'dashicons-media-document',
            27
        );
        add_options_page(
            'Monitorul Oficial Local',
            'Monitorul Oficial Local',
            'manage_options',
            'pbv-mol-settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('pbv_mol_settings', 'pbv_drive_api_key', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ));
    }

    private function catalog_file() {
        $uploads = wp_upload_dir();
        return trailingslashit($uploads['basedir']) . self::CATALOG_RELATIVE_PATH;
    }

    private function read_catalog() {
        $file = $this->catalog_file();
        if (!is_readable($file)) {
            return array();
        }
        $raw = file_get_contents($file);
        if ($raw === false) {
            return array();
        }
        $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return array();
        }
        $entries = array();
        foreach ($decoded as $entry) {
            if (is_array($entry)) {
                $entries[] = $this->normalise_entry($entry);
            }
        }
        return $entries;
    }

    private function normalise_entry($entry) {
        $title = isset($entry['Title']) ? sanitize_text_field($entry['Title']) : '';
        $path = isset($entry['Path']) ? sanitize_text_field($entry['Path']) : '';
        $departments = array();
        if (!empty($entry['Departments']) && is_array($entry['Departments'])) {
            $departments = array_map('sanitize_key', $entry['Departments']);
        } elseif (!empty($entry['Department'])) {
            $departments = array(sanitize_key($entry['Department']));
        } else {
            foreach (array_keys($this->departments) as $department) {
                if (strpos(strtolower($path), '/' . $department . '/') !== false || strpos(strtolower($path), $department . '/') !== false) {
                    $departments[] = $department;
                    break;
                }
            }
        }
        $departments = array_values(array_unique(array_intersect($departments, array_keys($this->departments))));
        if (!$departments) {
            $departments = array('diverse-si-544');
        }
        $entry_id = isset($entry['Id']) ? sanitize_key($entry['Id']) : '';
        if (!$entry_id) {
            $entry_id = substr(md5(strtolower($path . '|' . $title)), 0, 16);
        }
        $size = isset($entry['Size']) ? sanitize_text_field($entry['Size']) : '';
        return array(
            'Id' => $entry_id,
            'Title' => $title,
            'Path' => $path,
            'Departments' => $departments,
            'Size' => $size,
            'Status' => isset($entry['Status']) ? sanitize_text_field($entry['Status']) : 'OK',
        );
    }

    private function save_catalog($entries) {
        $file = $this->catalog_file();
        $directory = dirname($file);
        if (!wp_mkdir_p($directory)) {
            return new WP_Error('pbv_catalog_directory', 'Nu s-a putut crea directorul catalogului de formulare.');
        }
        $clean = array();
        foreach ($entries as $entry) {
            if (is_array($entry)) {
                $clean[] = $this->normalise_entry($entry);
            }
        }
        $json = wp_json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false || file_put_contents($file, $json . PHP_EOL, LOCK_EX) === false) {
            return new WP_Error('pbv_catalog_write', 'Nu s-a putut salva catalogul JSON. Verificați drepturile de scriere pentru wp-content/uploads/formulare/.');
        }
        return true;
    }

    private function forms_admin_url($message) {
        wp_safe_redirect(add_query_arg('pbv_message', rawurlencode($message), admin_url('admin.php?page=pbv-formulare')));
        exit;
    }

    public function handle_form_add() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a modifica formularele.', 403);
        }
        check_admin_referer('pbv_forms_add', 'pbv_forms_nonce');

        $title = isset($_POST['pbv_title']) ? sanitize_text_field(wp_unslash($_POST['pbv_title'])) : '';
        $selected = isset($_POST['pbv_departments']) ? (array) wp_unslash($_POST['pbv_departments']) : array();
        $departments = array_values(array_unique(array_intersect(array_map('sanitize_key', $selected), array_keys($this->departments))));
        if ($title === '' || !$departments || empty($_FILES['pbv_docx']['name'])) {
            $this->forms_admin_url('missing');
        }

        $file = $_FILES['pbv_docx'];
        if (!empty($file['error']) || empty($file['tmp_name']) || strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'docx') {
            $this->forms_admin_url('invalid_file');
        }
        if (!empty($file['size']) && (int) $file['size'] > 10 * 1024 * 1024) {
            $this->forms_admin_url('too_large');
        }
        $signature = file_get_contents($file['tmp_name'], false, null, 0, 4);
        if ($signature !== "PK\x03\x04") {
            $this->forms_admin_url('invalid_file');
        }
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($file['tmp_name']) !== true || $zip->locateName('word/document.xml') === false || $zip->locateName('[Content_Types].xml') === false) {
                if ($zip->status === ZipArchive::ER_OK) {
                    $zip->close();
                }
                $this->forms_admin_url('invalid_file');
            }
            $zip->close();
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        add_filter('upload_dir', array($this, 'forms_upload_directory'));
        $uploaded = wp_handle_upload($file, array(
            'test_form' => false,
            'mimes' => array('docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
        ));
        remove_filter('upload_dir', array($this, 'forms_upload_directory'));
        if (!is_array($uploaded) || !empty($uploaded['error'])) {
            $this->forms_admin_url('upload_failed');
        }

        $relative_path = 'formulare/' . basename($uploaded['file']);
        $entries = $this->read_catalog();
        $entries[] = array(
            'Id' => substr(md5(strtolower($relative_path . '|' . $title)), 0, 16),
            'Title' => $title,
            'Path' => $relative_path,
            'Departments' => $departments,
            'Size' => size_format((int) $file['size']),
            'Status' => 'OK',
        );
        $saved = $this->save_catalog($entries);
        if (is_wp_error($saved)) {
            $this->forms_admin_url('save_failed');
        }
        $this->forms_admin_url('added');
    }

    public function forms_upload_directory($directories) {
        $directories['subdir'] = '/formulare';
        $directories['path'] = trailingslashit($directories['basedir']) . 'formulare';
        $directories['url'] = trailingslashit($directories['baseurl']) . 'formulare';
        wp_mkdir_p($directories['path']);
        return $directories;
    }

    public function handle_form_delete() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a șterge formulare.', 403);
        }
        check_admin_referer('pbv_forms_delete', 'pbv_forms_nonce');
        $id = isset($_POST['pbv_form_id']) ? sanitize_key(wp_unslash($_POST['pbv_form_id'])) : '';
        $entries = $this->read_catalog();
        $remaining = array();
        $removed = false;
        foreach ($entries as $entry) {
            if (!$removed && hash_equals($entry['Id'], $id)) {
                $removed = true;
                continue;
            }
            $remaining[] = $entry;
        }
        if (!$removed) {
            $this->forms_admin_url('not_found');
        }
        $saved = $this->save_catalog($remaining);
        if (is_wp_error($saved)) {
            $this->forms_admin_url('save_failed');
        }
        $this->forms_admin_url('deleted');
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $messages = array(
            'missing' => 'Completați titlul, încărcați un fișier DOCX și selectați cel puțin un compartiment.',
            'invalid_file' => 'Fișier invalid: acceptăm doar documente DOCX valide.',
            'too_large' => 'Fișierul depășește limita de 10 MB.',
            'upload_failed' => 'Încărcarea a eșuat. Verificați limita și permisiunile de încărcare WordPress.',
            'save_failed' => 'Catalogul JSON nu a putut fi salvat. Verificați drepturile de scriere.',
            'added' => 'Formularul a fost încărcat și adăugat în catalog.',
            'deleted' => 'Formularul a fost scos din JSON și din pagina publică. Fișierul încărcat rămâne în biblioteca de upload-uri.',
            'not_found' => 'Formularul nu a mai fost găsit în catalog.',
        );
        $message_key = isset($_GET['pbv_message']) ? sanitize_key(wp_unslash($_GET['pbv_message'])) : '';
        $entries = $this->read_catalog();
        ?>
        <div class="wrap">
            <h1>Administrare Formulare</h1>
            <p>Încărcați fișiere DOCX și selectați unul sau mai multe compartimente. Un document comun rămâne o singură înregistrare în JSON și apare la filtrarea fiecărui compartiment selectat.</p>
            <?php if (isset($messages[$message_key])) : ?>
                <div class="notice <?php echo in_array($message_key, array('added', 'deleted'), true) ? 'notice-success' : 'notice-error'; ?> is-dismissible"><p><?php echo esc_html($messages[$message_key]); ?></p></div>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" style="max-width:760px;background:#fff;padding:20px;margin:20px 0;border:1px solid #c3c4c7;">
                <input type="hidden" name="action" value="pbv_forms_add">
                <?php wp_nonce_field('pbv_forms_add', 'pbv_forms_nonce'); ?>
                <p><label for="pbv-title"><strong>Denumirea formularului</strong></label><br><input id="pbv-title" name="pbv_title" class="regular-text" required></p>
                <p><label for="pbv-docx"><strong>Fișier DOCX</strong></label><br><input id="pbv-docx" type="file" name="pbv_docx" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required><br><small>Limită: 10 MB. Fișierul se salvează în wp-content/uploads/formulare/.</small></p>
                <fieldset><legend><strong>Compartiment (selectați unul sau mai multe)</strong></legend>
                    <?php foreach ($this->departments as $key => $label) : ?>
                        <label style="display:inline-block;margin:8px 16px 0 0;"><input type="checkbox" name="pbv_departments[]" value="<?php echo esc_attr($key); ?>"> <?php echo esc_html($label); ?></label>
                    <?php endforeach; ?>
                </fieldset>
                <?php submit_button('Încarcă și adaugă formularul'); ?>
            </form>
            <h2>Formulare în catalog (<?php echo esc_html((string) count($entries)); ?>)</h2>
            <table class="widefat striped">
                <thead><tr><th>Denumire</th><th>Compartimente</th><th>Fișier</th><th>Acțiune</th></tr></thead>
                <tbody>
                <?php if (!$entries) : ?>
                    <tr><td colspan="4">Catalogul este gol sau nu poate fi citit.</td></tr>
                <?php else : foreach ($entries as $entry) : ?>
                    <tr>
                        <td><?php echo esc_html($entry['Title']); ?></td>
                        <td><?php echo esc_html(implode(', ', array_map(function ($department) { return isset($this->departments[$department]) ? $this->departments[$department] : $department; }, $entry['Departments']))); ?></td>
                        <td><?php echo esc_html(basename($entry['Path'])); ?></td>
                        <td><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Scoateți acest formular din catalogul public? Fișierul nu va fi șters.');">
                            <input type="hidden" name="action" value="pbv_forms_delete"><input type="hidden" name="pbv_form_id" value="<?php echo esc_attr($entry['Id']); ?>">
                            <?php wp_nonce_field('pbv_forms_delete', 'pbv_forms_nonce'); ?><button class="button button-secondary" type="submit">Șterge din listă</button>
                        </form></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>Monitorul Oficial Local – Google Drive</h1>
            <p>Arhiva de foldere este construită din fișierul „Google Drive ID.csv”. Pentru a activa căutarea numelor de fișiere, introduceți o cheie API Google Cloud cu Google Drive API v3 activat. Folder-ele și fișierele căutate trebuie să fie accesibile public pentru citire.</p>
            <p>Restricționați cheia API la domeniul site-ului (HTTP referrer) și la API-ul Google Drive; aceasta este vizibilă în browser, deci nu trebuie să aibă permisiuni de scriere sau acces privat.</p>
            <form method="post" action="options.php">
                <?php settings_fields('pbv_mol_settings'); ?>
                <table class="form-table" role="presentation"><tr>
                    <th scope="row"><label for="pbv-drive-api-key">Cheie API Google Drive</label></th>
                    <td><input id="pbv-drive-api-key" name="pbv_drive_api_key" type="password" class="regular-text" value="<?php echo esc_attr(get_option('pbv_drive_api_key', '')); ?>" autocomplete="new-password"><p class="description">Opțională. Fără cheie, navigarea prin foldere și iframe-ul funcționează, dar căutarea după nume este dezactivată.</p></td>
                </tr></table>
                <?php submit_button('Salvează setările'); ?>
            </form>
        </div>
        <?php
    }

    public function enqueue_public_assets() {
        if (!is_singular()) {
            return;
        }
        global $post;
        $content = $post instanceof WP_Post ? $post->post_content : '';
        $needed = has_shortcode($content, 'pbv_formulare') || has_shortcode($content, 'pbv_mol_browser') || is_page('formulare') || is_page('monitorul-oficial-local');
        if (!$needed && function_exists('is_page_template')) {
            $needed = is_page_template('page-formulare.php') || is_page_template('page-monitorul-oficial.php');
        }
        if (!$needed) {
            return;
        }
        wp_enqueue_style('pbv-site-enhancements', plugin_dir_url(__FILE__) . 'assets/pbv-site.css', array(), self::VERSION);
        wp_enqueue_script('pbv-site-enhancements', plugin_dir_url(__FILE__) . 'assets/pbv-site.js', array(), self::VERSION, true);
        wp_localize_script('pbv-site-enhancements', 'pbvSiteEnhancements', array(
            'driveApiKey' => (string) get_option('pbv_drive_api_key', ''),
            'strings' => array(
                'chooseFolder' => 'Selectați mai întâi un folder din listă.',
                'enterSearch' => 'Introduceți un termen de căutare.',
                'noApiKey' => 'Căutarea după nume necesită configurarea unei chei API în Setări → Monitorul Oficial Local.',
                'loading' => 'Se caută fișiere în folderul selectat…',
                'noResults' => 'Nu au fost găsite fișiere cu acest nume în folderul selectat.',
                'results' => 'fișiere găsite',
                'apiError' => 'Căutarea nu a putut fi efectuată. Verificați cheia API, activarea Google Drive API și accesul public la folder.',
                'selectFolder' => 'Alegeți o categorie sau un an pentru a vedea documentele din Drive.',
                'searchIn' => 'Căutare în',
            ),
        ));
    }

    private function upload_url($stored_path) {
        $stored_path = str_replace('\\', '/', ltrim($stored_path, '/'));
        $needle = 'wp-content/uploads/';
        $position = strpos($stored_path, $needle);
        if ($position !== false) {
            $stored_path = substr($stored_path, $position + strlen($needle));
        } elseif (strpos($stored_path, 'uploads/') === 0) {
            $stored_path = substr($stored_path, strlen('uploads/'));
        }
        if (strpos($stored_path, 'formulare/') !== 0) {
            $stored_path = 'formulare/' . basename($stored_path);
        }
        $uploads = wp_upload_dir();
        return trailingslashit($uploads['baseurl']) . implode('/', array_map('rawurlencode', explode('/', $stored_path)));
    }

    public function forms_shortcode() {
        $entries = $this->read_catalog();
        $counts = array_fill_keys(array_keys($this->departments), 0);
        foreach ($entries as $entry) {
            foreach ($entry['Departments'] as $department) {
                if (isset($counts[$department])) {
                    $counts[$department]++;
                }
            }
        }
        ob_start();
        ?>
        <div class="pbv-managed-forms" data-pbv-forms>
            <label class="pbv-forms-search-label" for="pbv-managed-search">Caută formulare</label>
            <input type="search" id="pbv-managed-search" class="pbv-forms-search" data-forms-search placeholder="Caută după denumire…">
            <div class="pbv-forms-tabs" role="group" aria-label="Filtrează formularele">
                <button type="button" class="pbv-forms-tab is-active" data-forms-filter="all" aria-pressed="true">Toate <span><?php echo esc_html((string) count($entries)); ?></span></button>
                <?php foreach ($this->departments as $key => $label) : ?>
                    <button type="button" class="pbv-forms-tab" data-forms-filter="<?php echo esc_attr($key); ?>" aria-pressed="false"><?php echo esc_html($label); ?> <span><?php echo esc_html((string) $counts[$key]); ?></span></button>
                <?php endforeach; ?>
            </div>
            <div class="pbv-forms-table-wrap"><table class="pbv-forms-managed-table">
                <thead><tr><th>Denumire Formular</th><th>Compartiment(e)</th><th>Format / Mărime</th><th>Acțiune</th></tr></thead>
                <tbody data-forms-list>
                <?php foreach ($entries as $entry) :
                    $categories = implode(' ', $entry['Departments']);
                    $format = strtoupper(pathinfo($entry['Path'], PATHINFO_EXTENSION));
                    $department_names = array_map(function ($key) { return isset($this->departments[$key]) ? $this->departments[$key] : $key; }, $entry['Departments']);
                    ?>
                    <tr class="pbv-managed-form-row" data-form-categories="<?php echo esc_attr($categories); ?>" data-form-title="<?php echo esc_attr(function_exists('mb_strtolower') ? mb_strtolower($entry['Title'], 'UTF-8') : strtolower($entry['Title'])); ?>">
                        <td><strong><?php echo esc_html($entry['Title']); ?></strong></td>
                        <td><?php echo esc_html(implode(', ', $department_names)); ?></td>
                        <td><span class="pbv-managed-format"><?php echo esc_html($format); ?></span> <?php echo esc_html($entry['Size']); ?></td>
                        <td><a class="pbv-btn pbv-btn-primary" href="<?php echo esc_url($this->upload_url($entry['Path'])); ?>" download>Descarcă</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
            <p class="pbv-forms-empty" data-forms-empty <?php echo $entries ? 'hidden' : ''; ?>>Nu există formulare în catalog.</p>
        </div>
        <?php
        return ob_get_clean();
    }

    private function drive_folders() {
        $file = plugin_dir_path(__FILE__) . self::DRIVE_DATA_FILE;
        if (!is_readable($file)) {
            return array();
        }
        $raw = file_get_contents($file);
        if ($raw === false) {
            return array();
        }
        $decoded = json_decode($raw, true);
        if (!isset($decoded['folders']) || !is_array($decoded['folders'])) {
            return array();
        }
        $resolved = PBV_Drive_Catalog_Manager::resolve_duplicates($decoded['folders']);
        return $resolved['folders'];
    }

    private function drive_tree() {
        $tree = array();
        foreach ($this->drive_folders() as $folder) {
            $segments = isset($folder['segments']) && is_array($folder['segments']) ? array_values($folder['segments']) : array();
            if (!$segments || empty($folder['id'])) {
                continue;
            }
            $branch =& $tree;
            foreach ($segments as $index => $segment) {
                $segment = sanitize_text_field($segment);
                if (!isset($branch[$segment])) {
                    $branch[$segment] = array('name' => $segment, 'id' => '', 'modified' => '', 'visible' => true, 'children' => array());
                }
                if ($index === count($segments) - 1) {
                    $branch[$segment]['id'] = sanitize_text_field($folder['id']);
                    $branch[$segment]['modified'] = isset($folder['modified']) ? sanitize_text_field($folder['modified']) : '';
                    $branch[$segment]['visible'] = !array_key_exists('visible', $folder) || (bool) $folder['visible'];
                }
                $branch =& $branch[$segment]['children'];
            }
            unset($branch);
        }
        return $tree;
    }

    private function drive_label($name) {
        $labels = array(
            '1Statut' => '1. Statutul unității administrativ-teritoriale',
            '2Regul' => '2. Regulamentele privind procedurile administrative',
            '3ArhPHCL' => '3.1 Proiecte de hotărâri ale Autorității Deliberative – arhivă',
            '3PHCL' => '3.1 Proiecte de hotărâri ale Autorității Deliberative – anul curent',
            '3ArhHCL' => '3.2 Hotărârile Autorității Deliberative – arhivă',
            '3HCL' => '3.2 Hotărârile Autorității Deliberative – anul curent',
            '4ArhPDPr' => '4.1 Proiecte de dispoziții ale Autorității Executive – arhivă',
            '4PDPr' => '4.1 Proiecte de dispoziții ale Autorității Executive – anul curent',
            '4ArhDPr' => '4.2 Dispozițiile Autorității Executive – arhivă',
            '4DPr' => '4.2 Dispozițiile Autorității Executive – anul curent',
            '51PrB' => '5.1 Proiect buget',
            '52Datorie' => '5.2 Datoria publică locală',
            '53Buget' => '5.3 Buget local pe surse de finanțare',
            '54Bilant' => '5.4 Bilanț contabil',
            '61Refuz' => '6.1 Registrul refuzurilor de a semna acte administrative',
            '62PrPrH' => '6.2 Registru propuneri la proiectele de hotărâre',
            '63PrANorm' => '6.3 Proiecte de acte normative',
            '64PVSed' => '6.4 Procese-verbale ale ședințelor',
            '65IntPb' => '6.5 Probleme de interes public',
            '66Minute' => '6.6 Minutele ședințelor',
            '67Avere' => '6.7 Declarații de avere',
            '68Interese' => '6.8 Declarații de interese',
            '69DCasat' => '6.9 Declarații de căsătorie',
            '6101Ziar' => '6.10.1 Ziarul local',
            '6102VinzTeren' => '6.10.2 Oferte de vânzare teren',
            '6103Licitatii' => '6.10.3 Achiziții publice',
            '6104Convoc' => '6.10.4 Convocator',
            '6106Concurs' => '6.10.5 Concursuri',
            '71SPPS' => 'S.C. Serviciu Public Prestări Servicii Beba Veche S.R.L.',
            '72Constructii' => 'S.C. Construcții 2015 Beba Veche S.R.L.',
            '73Spatii' => 'S.C. Spații verzi Beba Veche S.R.L.',
            '7Societati' => 'Informații societăți',
            'PVSed' => 'Procese-verbale ale ședințelor (folder suplimentar)',
            'arhVinzare' => 'Arhivă vânzare terenuri',
        );
        return isset($labels[$name]) ? $labels[$name] : $name;
    }

    private function drive_node_has_visible_content($node) {
        if (isset($node['visible']) && !$node['visible']) {
            return false;
        }
        if (!empty($node['id'])) {
            return true;
        }
        if (!empty($node['children'])) {
            foreach ($node['children'] as $child) {
                if ($this->drive_node_has_visible_content($child)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function visible_drive_nodes($nodes) {
        $visible = array();
        foreach ($nodes as $name => $node) {
            if ($this->drive_node_has_visible_content($node)) {
                $visible[$name] = $node;
            }
        }
        return $visible;
    }

    private function sort_drive_nodes($nodes, $depth) {
        $names = array_keys($nodes);
        if ($depth === 0) {
            $root_order = array(
                '1Statut', '2Regul',
                '3PHCL', '3ArhPHCL', '3HCL', '3ArhHCL',
                '4PDPr', '4ArhPDPr', '4DPr', '4ArhDPr',
                '51PrB', '52Datorie', '53Buget', '54Bilant',
                '61Refuz', '62PrPrH', '63PrANorm', '64PVSed', '65IntPb', '66Minute', '67Avere', '68Interese', '69DCasat', '6101Ziar', '6102VinzTeren', '6103Licitatii', '6104Convoc', '6106Concurs',
                '7Societati', '71SPPS', '72Constructii', '73Spatii',
            );
            $rank = array_flip($root_order);
            $fallback = count($rank);
            usort($names, function ($first, $second) use ($rank, $fallback) {
                $first_rank = isset($rank[$first]) ? $rank[$first] : $fallback;
                $second_rank = isset($rank[$second]) ? $rank[$second] : $fallback;
                return $first_rank === $second_rank ? strnatcasecmp($first, $second) : ($first_rank <=> $second_rank);
            });
        } else {
            usort($names, function ($first, $second) {
                $first_year = preg_match('/^\d{4}$/', (string) $first) === 1;
                $second_year = preg_match('/^\d{4}$/', (string) $second) === 1;
                if ($first_year && $second_year) {
                    return (int) $second <=> (int) $first;
                }
                if ($first_year !== $second_year) {
                    return $first_year ? -1 : 1;
                }
                $natural = strnatcasecmp($first, $second);
                return $natural !== 0 ? $natural : strcmp($first, $second);
            });
        }
        $sorted = array();
        foreach ($names as $name) {
            if (isset($nodes[$name])) {
                $sorted[$name] = $nodes[$name];
            }
        }
        return $sorted;
    }

    private function render_drive_nodes($nodes, $depth = 0) {
        if (!$nodes || $depth > 6) {
            return;
        }
        $nodes = $this->sort_drive_nodes($nodes, $depth);
        echo '<ul class="pbv-mol-folder-list">';
        foreach ($nodes as $node) {
            if (isset($node['visible']) && !$node['visible']) {
                continue;
            }
            $label = $this->drive_label($node['name']);
            echo '<li class="pbv-mol-folder-item">';
            if (!empty($node['id'])) {
                echo '<button type="button" class="pbv-mol-folder-button" data-drive-folder="' . esc_attr($node['id']) . '" data-drive-name="' . esc_attr($label) . '"><span aria-hidden="true">📁</span> ' . esc_html($label) . '</button>';
            } else {
                echo '<span class="pbv-mol-folder-label">' . esc_html($label) . '</span>';
            }
            if (!empty($node['children'])) {
                $visible_children = $this->visible_drive_nodes($node['children']);
                if ($visible_children) {
                    $children_are_years = true;
                    foreach (array_keys($visible_children) as $child_name) {
                        if (!preg_match('/^\d{4}$/', (string) $child_name)) {
                            $children_are_years = false;
                            break;
                        }
                    }
                    $open_years = $children_are_years ? ' open' : '';
                    echo '<details class="pbv-mol-children"' . $open_years . '><summary>Subfoldere / ani (' . esc_html((string) count($visible_children)) . ')</summary>';
                    $this->render_drive_nodes($visible_children, $depth + 1);
                    echo '</details>';
                }
            }
            echo '</li>';
        }
        echo '</ul>';
    }

    public function mol_shortcode() {
        $tree = $this->drive_tree();
        $groups = array();
        foreach ($tree as $name => $node) {
            if (!$this->drive_node_has_visible_content($node)) {
                continue;
            }
            preg_match('/^([1-7])/', $name, $match);
            $group = !empty($match[1]) ? $match[1] : 'other';
            $groups[$group][$name] = $node;
        }
        $group_order = array('1', '2', '3', '4', '5', '6', '7', 'other');
        $group_rank = array_flip($group_order);
        uksort($groups, function ($first, $second) use ($group_rank) {
            $first_rank = isset($group_rank[$first]) ? $group_rank[$first] : PHP_INT_MAX;
            $second_rank = isset($group_rank[$second]) ? $group_rank[$second] : PHP_INT_MAX;
            return $first_rank <=> $second_rank;
        });
        $group_labels = array(
            '1' => '1. Statutul unității administrativ-teritoriale',
            '2' => '2. Regulamentele privind procedurile administrative',
            '3' => '3. Hotărârile Autorității Deliberative',
            '4' => '4. Dispozițiile Autorității Executive',
            '5' => '5. Documente și informații financiare',
            '6' => '6. Alte documente',
            '7' => 'Informații societăți',
            'other' => 'Arhive suplimentare',
        );
        $first_folder = $this->first_visible_drive_id($tree);
        ob_start();
        ?>
        <div class="pbv-mol-browser" data-pbv-mol data-initial-folder="<?php echo esc_attr($first_folder); ?>">
            <div class="pbv-mol-notice"><strong>Arhiva oficială de documente</strong><p>Selectați categoria, apoi folderul sau anul. Fiecare buton deschide folderul Google Drive asociat exact ID-ului din lista furnizată. Folderele fără an sunt dosarele curente.</p></div>
            <div class="pbv-mol-browser-layout">
                <nav class="pbv-mol-navigation" aria-label="Categorii și foldere Monitorul Oficial Local">
                    <h2>Structura arhivei</h2>
                    <?php if (!$groups) : ?>
                        <p>Lista de foldere Google Drive nu a putut fi încărcată. Verificați instalarea pluginului.</p>
                    <?php else : foreach ($groups as $key => $nodes) : ?>
                        <details class="pbv-mol-group" <?php echo in_array($key, array('1', '3', '4'), true) ? 'open' : ''; ?>>
                            <summary><?php echo esc_html(isset($group_labels[$key]) ? $group_labels[$key] : $group_labels['other']); ?></summary>
                            <?php $this->render_drive_nodes($nodes); ?>
                        </details>
                    <?php endforeach; endif; ?>
                </nav>
                <section class="pbv-mol-viewer" aria-label="Documentele selectate din Google Drive">
                    <div class="pbv-mol-selected"><strong>Folder selectat:</strong> <span data-drive-selected>—</span></div>
                    <form class="pbv-mol-search" data-drive-search-form>
                        <label for="pbv-drive-search">Caută în numele fișierelor din folderul selectat</label>
                        <div><input id="pbv-drive-search" type="search" data-drive-search-input placeholder="Ex.: hotărâre, buget, președinte…"><button class="pbv-btn pbv-btn-primary" type="submit">Caută</button></div>
                    </form>
                    <p class="pbv-mol-search-note" data-drive-search-note></p>
                    <div class="pbv-mol-search-results" data-drive-search-results aria-live="polite"></div>
                    <div class="pbv-drive-frame-wrapper"><iframe class="pbv-drive-frame" data-drive-frame title="Documente Google Drive din folderul selectat" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
                    <p class="pbv-mol-open-drive"><a data-drive-open-link href="https://drive.google.com" target="_blank" rel="noopener noreferrer">Deschide folderul în Google Drive</a></p>
                </section>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function first_visible_drive_id($nodes) {
        foreach ($nodes as $node) {
            if (isset($node['visible']) && !$node['visible']) {
                continue;
            }
            if (!empty($node['id'])) {
                return $node['id'];
            }
            if (!empty($node['children'])) {
                $child_id = $this->first_visible_drive_id($node['children']);
                if ($child_id !== '') {
                    return $child_id;
                }
            }
        }
        return '';
    }
}

$pbv_site_enhancements = new PBV_Site_Enhancements();
$pbv_drive_catalog_manager = new PBV_Drive_Catalog_Manager(plugin_dir_path(__FILE__) . 'data/google-drive-folders.json');
$pbv_media_gallery = new PBV_Media_Gallery();
register_activation_hook(__FILE__, array('PBV_Site_Enhancements', 'activate'));
