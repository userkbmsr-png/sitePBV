(function () {
  'use strict';

  function initialise(gallery) {
    var slides = Array.prototype.slice.call(gallery.querySelectorAll('[data-pbv-media-slide]'));
    var controls = gallery.querySelector('[data-pbv-media-controls]');
    var status = gallery.querySelector('[data-pbv-media-status]');
    var thumbnailRail = gallery.querySelector('[data-pbv-media-thumbnails]');
    var thumbnails = Array.prototype.slice.call(gallery.querySelectorAll('[data-pbv-media-thumbnail]'));
    if (!slides.length) return;

    var indicators = Array.prototype.slice.call(gallery.querySelectorAll('[data-pbv-media-indicator]'));
    var current = 0;
    gallery.classList.add('is-ready');

    function show(index) {
      current = (index + slides.length) % slides.length;
      slides.forEach(function (slide, slideIndex) {
        slide.hidden = slideIndex !== current;
        if (slideIndex !== current) {
          var video = slide.querySelector('video');
          if (video && !video.paused) video.pause();
        }
      });

      indicators.forEach(function (indicator, indicatorIndex) {
        if (indicatorIndex === current) {
          indicator.setAttribute('aria-current', 'true');
        } else {
          indicator.removeAttribute('aria-current');
        }
      });

      var activeThumbnail = null;
      thumbnails.forEach(function (thumbnail) {
        var active = Number(thumbnail.getAttribute('data-pbv-media-thumbnail')) === current;
        thumbnail.setAttribute('aria-pressed', active ? 'true' : 'false');
        if (active) activeThumbnail = thumbnail;
      });
      if (activeThumbnail && thumbnailRail) {
        var railRect = thumbnailRail.getBoundingClientRect();
        var thumbnailRect = activeThumbnail.getBoundingClientRect();
        if (thumbnailRect.left < railRect.left) {
          thumbnailRail.scrollLeft -= railRect.left - thumbnailRect.left;
        } else if (thumbnailRect.right > railRect.right) {
          thumbnailRail.scrollLeft += thumbnailRect.right - railRect.right;
        }
      }

      if (status) {
        var title = slides[current].getAttribute('data-media-title') || '';
        status.textContent = 'Elementul ' + (current + 1) + ' din ' + slides.length + (title ? ': ' + title : '');
      }
    }

    show(0);
    thumbnails.forEach(function (thumbnail) {
      thumbnail.addEventListener('click', function () {
        var slideIndex = Number(thumbnail.getAttribute('data-pbv-media-thumbnail'));
        if (Number.isInteger(slideIndex) && slideIndex >= 0 && slideIndex < slides.length) {
          show(slideIndex);
        }
      });
    });
    if (slides.length < 2 || !controls) return;

    controls.hidden = false;
    var previous = gallery.querySelector('[data-pbv-media-prev]');
    var next = gallery.querySelector('[data-pbv-media-next]');
    if (previous) previous.addEventListener('click', function () { show(current - 1); });
    if (next) next.addEventListener('click', function () { show(current + 1); });
    indicators.forEach(function (indicator) {
      indicator.addEventListener('click', function () {
        show(Number(indicator.getAttribute('data-pbv-media-indicator')) || 0);
      });
    });

    gallery.addEventListener('keydown', function (event) {
      if (event.target && event.target.closest && event.target.closest('video, audio, input, textarea, select')) return;
      if (event.key === 'ArrowLeft') {
        event.preventDefault();
        show(current - 1);
      } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        show(current + 1);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.pbv-media-gallery').forEach(initialise);
  });
}());
