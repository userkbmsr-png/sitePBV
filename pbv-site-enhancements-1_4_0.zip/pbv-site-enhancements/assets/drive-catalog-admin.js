(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('pbv-drive-catalog-form');
    var rows = document.querySelector('[data-pbv-folder-rows]');
    var template = document.querySelector('[data-pbv-folder-template]');
    var addButton = document.querySelector('[data-pbv-add-folder]');
    var config = window.pbvDriveCatalogAdmin || {};
    if (!form || !rows || !template || !addButton) return;

    var nextIndex = Number(window.pbvDriveCatalogNextIndex || rows.children.length);
    var dirty = false;
    var idPattern = /^[A-Za-z0-9_-]{5,200}$/;

    function getRowValue(row) {
      var parentInput = row.querySelector('input[name$="[parent]"]');
      var childInput = row.querySelector('input[name$="[subfolder]"]');
      var idInput = row.querySelector('input[name$="[id]"]');
      var parent = parentInput ? parentInput.value.trim() : '';
      var child = childInput ? childInput.value.trim() : '';
      var id = idInput ? idInput.value.trim() : '';
      if (!parent) return { error: 'Completați câmpul Parinte.' };
      var segments = parent.split('/').map(function (part) { return part.trim(); });
      if (segments.some(function (part) { return !part; })) return { error: 'Calea din Parinte conține un segment gol.' };
      if (segments.length && segments[0].toLocaleLowerCase('ro') === 'mofl') segments.shift();
      if (child.indexOf('/') !== -1 || child === '.' || child === '..') return { error: 'Subfolder trebuie să fie un singur nume, fără slash.' };
      if (!segments.length && !child) return { error: 'MofL este rădăcina catalogului; completați Subfolder pentru folderul nou.' };
      if (!idPattern.test(id)) return { error: 'ID-ul nu are formatul așteptat (litere, cifre, „_” sau „-”).' };
      if (child) segments.push(child);
      return {
        segments: segments,
        name: segments[segments.length - 1],
        parentKey: segments.length > 1 ? segments.slice(0, -1).join('\u001f') : '',
        key: segments.join('\u001f'),
        id: id
      };
    }

    function setStatus(output, message, state) {
      output.textContent = message;
      output.setAttribute('data-test-state', state || '');
    }

    function testRow(button) {
      var row = button.closest('[data-pbv-folder-row]');
      var output = row && row.querySelector('[data-pbv-test-result]');
      if (!row || !output) return;
      var value = getRowValue(row);
      var modifiedInput = row.querySelector('[data-pbv-folder-modified]');
      var testedInput = row.querySelector('[data-pbv-folder-tested]');
      var proofInput = row.querySelector('[data-pbv-folder-proof]');
      if (value.error) {
        setStatus(output, value.error, 'error');
        return;
      }
      button.disabled = true;
      setStatus(output, 'Se verifică read-only în Google Drive…', 'pending');
      var params = new URLSearchParams({
        action: 'pbv_drive_catalog_test',
        nonce: config.nonce || '',
        id: value.id,
        segments: JSON.stringify(value.segments)
      });
      fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: params.toString()
      }).then(function (response) {
        return response.json();
      }).then(function (result) {
        if (!result || !result.success || !result.data) {
          var message = result && result.data && result.data.message ? result.data.message : (config.strings && config.strings.unavailable);
          throw new Error(message || 'Testul Google Drive a eșuat.');
        }
        if (modifiedInput) modifiedInput.value = result.data.modified;
        if (testedInput) testedInput.value = '1';
        if (proofInput) proofInput.value = result.data.proof;
        dirty = true;
        setStatus(output, result.data.message || 'Verificat cu Google Drive API.', 'ok');
      }).catch(function (error) {
        if (modifiedInput) modifiedInput.value = '';
        if (testedInput) testedInput.value = '0';
        if (proofInput) proofInput.value = '';
        setStatus(output, error && error.message ? error.message : (config.strings && config.strings.unavailable) || 'Testul Google Drive a eșuat.', 'error');
      }).finally(function () {
        button.disabled = false;
      });
    }

    addButton.addEventListener('click', function () {
      var html = template.innerHTML.replace(/__INDEX__/g, String(nextIndex++));
      var wrapper = document.createElement('tbody');
      wrapper.innerHTML = html;
      while (wrapper.firstChild) rows.appendChild(wrapper.firstChild);
      dirty = true;
      var firstInput = rows.lastElementChild && rows.lastElementChild.querySelector('input[type="text"]');
      if (firstInput) firstInput.focus();
    });

    function deleteRow(button) {
      var row = button.closest('[data-pbv-folder-row]');
      if (!row) return;
      var savedId = row.getAttribute('data-pbv-saved-id');
      if (!savedId) {
        // Row not saved yet: only drop it from the form.
        row.remove();
        dirty = true;
        return;
      }
      var path = row.getAttribute('data-pbv-path') || '';
      var samePath = rows.querySelectorAll('[data-pbv-folder-row][data-pbv-path="' + path.replace(/"/g, '\\"') + '"]').length;
      var descendants = 0;
      if (samePath < 2) {
        Array.prototype.forEach.call(rows.querySelectorAll('[data-pbv-folder-row][data-pbv-path]'), function (other) {
          if ((other.getAttribute('data-pbv-path') || '').indexOf(path + ' / ') === 0) descendants += 1;
        });
      }
      var message = 'Ștergeți „' + path + '”' + (descendants ? ' și cele ' + descendants + ' subfoldere ale lui' : '') + ' din catalogul JSON?\nAcțiunea se aplică imediat și nu poate fi anulată.' + (dirty ? '\nModificările nesalvate din pagină se vor pierde.' : '');
      if (!window.confirm(message)) return;
      var hashInput = form.querySelector('[name="pbv_catalog_hash"]');
      button.disabled = true;
      var params = new URLSearchParams({
        action: 'pbv_drive_catalog_delete',
        nonce: config.deleteNonce || '',
        index: row.getAttribute('data-pbv-index') || '',
        id: savedId,
        hash: hashInput ? hashInput.value : ''
      });
      fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: params.toString()
      }).then(function (response) {
        return response.json();
      }).then(function (result) {
        if (!result || !result.success) {
          throw new Error(result && result.data && result.data.message ? result.data.message : 'Ștergerea a eșuat.');
        }
        dirty = false;
        window.location.href = (config.adminUrl || window.location.pathname + '?page=pbv-drive-folder-manager') + '&pbv_manager_notice=deleted';
      }).catch(function (error) {
        button.disabled = false;
        window.alert(error && error.message ? error.message : 'Ștergerea a eșuat.');
      });
    }

    rows.addEventListener('click', function (event) {
      var button = event.target.closest('[data-pbv-test-folder]');
      if (button) {
        testRow(button);
        return;
      }
      var del = event.target.closest('[data-pbv-delete-folder]');
      if (del) deleteRow(del);
    });

    function invalidateRowTest(target) {
      var row = target.closest('[data-pbv-folder-row]');
      if (!row) return;
      var modifiedInput = row.querySelector('[data-pbv-folder-modified]');
      var testedInput = row.querySelector('[data-pbv-folder-tested]');
      var proofInput = row.querySelector('[data-pbv-folder-proof]');
      var output = row.querySelector('[data-pbv-test-result]');
      if (modifiedInput) modifiedInput.value = '';
      if (testedInput) testedInput.value = '0';
      if (proofInput) proofInput.value = '';
      if (output) setStatus(output, 'Valor schimbat: apăsați din nou Test înainte de salvare.', 'pending');
    }

    rows.addEventListener('input', function (event) {
      dirty = true;
      if (event.target.matches('input[name$="[parent]"], input[name$="[subfolder]"], input[name$="[id]"]')) invalidateRowTest(event.target);
    });
    rows.addEventListener('change', function (event) {
      dirty = true;
      if (event.target.matches('input[name$="[parent]"], input[name$="[subfolder]"], input[name$="[id]"]')) invalidateRowTest(event.target);
    });
    form.addEventListener('submit', function () { dirty = false; });
    window.addEventListener('beforeunload', function (event) {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = '';
    });
  });
}());
