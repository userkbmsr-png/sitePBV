document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-pbv-forms]').forEach(function (catalog) {
    var search = catalog.querySelector('[data-forms-search]');
    var rows = Array.prototype.slice.call(catalog.querySelectorAll('.pbv-managed-form-row'));
    var tabs = Array.prototype.slice.call(catalog.querySelectorAll('[data-forms-filter]'));
    var empty = catalog.querySelector('[data-forms-empty]');
    var active = 'all';

    function filterRows() {
      var term = search ? search.value.trim().toLocaleLowerCase('ro') : '';
      var visible = 0;
      rows.forEach(function (row) {
        var categories = (row.getAttribute('data-form-categories') || '').split(/\s+/);
        var title = (row.getAttribute('data-form-title') || '').toLocaleLowerCase('ro');
        var shown = (active === 'all' || categories.indexOf(active) !== -1) && (!term || title.indexOf(term) !== -1);
        row.hidden = !shown;
        if (shown) visible += 1;
      });
      if (empty) empty.hidden = visible > 0;
    }

    tabs.forEach(function (button) {
      button.addEventListener('click', function () {
        active = button.getAttribute('data-forms-filter') || 'all';
        tabs.forEach(function (tab) {
          var selected = tab === button;
          tab.classList.toggle('is-active', selected);
          tab.setAttribute('aria-pressed', selected ? 'true' : 'false');
        });
        filterRows();
      });
    });
    if (search) search.addEventListener('input', filterRows);
  });

  document.querySelectorAll('[data-pbv-mol]').forEach(function (browser) {
    var frame = browser.querySelector('[data-drive-frame]');
    var selectedLabel = browser.querySelector('[data-drive-selected]');
    var openLink = browser.querySelector('[data-drive-open-link]');
    var searchForm = browser.querySelector('[data-drive-search-form]');
    var searchInput = browser.querySelector('[data-drive-search-input]');
    var searchNote = browser.querySelector('[data-drive-search-note]');
    var results = browser.querySelector('[data-drive-search-results]');
    var selectedFolder = '';
    var selectedName = '';
    var strings = (window.pbvSiteEnhancements && window.pbvSiteEnhancements.strings) || {};

    function selectFolder(id, name, button) {
      if (!id) return;
      selectedFolder = id;
      selectedName = name || id;
      if (selectedLabel) selectedLabel.textContent = selectedName;
      if (frame) frame.src = 'https://drive.google.com/embeddedfolderview?id=' + encodeURIComponent(id) + '#list';
      if (openLink) openLink.href = 'https://drive.google.com/drive/folders/' + encodeURIComponent(id);
      if (results) results.replaceChildren();
      if (searchNote) searchNote.textContent = (strings.searchIn || 'Căutare în') + ' „' + selectedName + '”.';
      browser.querySelectorAll('[data-drive-folder]').forEach(function (item) {
        item.classList.toggle('is-selected', item === button);
        if (item === button) item.setAttribute('aria-current', 'true');
        else item.removeAttribute('aria-current');
      });
    }

    browser.querySelectorAll('[data-drive-folder]').forEach(function (button) {
      button.addEventListener('click', function () {
        selectFolder(button.getAttribute('data-drive-folder'), button.getAttribute('data-drive-name'), button);
      });
    });

    var initial = browser.getAttribute('data-initial-folder');
    if (initial) {
      var first = browser.querySelector('[data-drive-folder="' + CSS.escape(initial) + '"]');
      if (first) selectFolder(initial, first.getAttribute('data-drive-name'), first);
    }

    if (searchForm) {
      searchForm.addEventListener('submit', function (event) {
        event.preventDefault();
        if (results) results.replaceChildren();
        var term = searchInput ? searchInput.value.trim() : '';
        if (!selectedFolder) {
          if (searchNote) searchNote.textContent = strings.chooseFolder || 'Selectați un folder.';
          return;
        }
        if (!term) {
          if (searchNote) searchNote.textContent = strings.enterSearch || 'Introduceți un termen de căutare.';
          return;
        }
        var apiKey = window.pbvSiteEnhancements && window.pbvSiteEnhancements.driveApiKey;
        if (!apiKey) {
          if (searchNote) searchNote.textContent = strings.noApiKey || 'Căutarea necesită o cheie API.';
          return;
        }
        if (searchNote) searchNote.textContent = strings.loading || 'Se caută…';
        var files = [];
        var token = '';
        var query = "'" + selectedFolder.replace(/'/g, '') + "' in parents and trashed = false";

        function fetchPage() {
          var params = new URLSearchParams({
            q: query,
            pageSize: '1000',
            fields: 'nextPageToken,files(id,name,mimeType,webViewLink,modifiedTime)',
            orderBy: 'name',
            includeItemsFromAllDrives: 'true',
            supportsAllDrives: 'true',
            key: apiKey
          });
          if (token) params.set('pageToken', token);
          return fetch('https://www.googleapis.com/drive/v3/files?' + params.toString())
            .then(function (response) {
              if (!response.ok) throw new Error('Drive API HTTP ' + response.status);
              return response.json();
            })
            .then(function (payload) {
              files = files.concat(payload.files || []);
              token = payload.nextPageToken || '';
              if (token) return fetchPage();
              return files;
            });
        }

        fetchPage().then(function (allFiles) {
          var needle = term.toLocaleLowerCase('ro');
          var matches = allFiles.filter(function (file) {
            return file.mimeType !== 'application/vnd.google-apps.folder' && (file.name || '').toLocaleLowerCase('ro').indexOf(needle) !== -1;
          });
          if (!results) return;
          if (!matches.length) {
            results.textContent = strings.noResults || 'Nu au fost găsite documente.';
            if (searchNote) searchNote.textContent = '0 ' + (strings.results || 'fișiere găsite') + ' în „' + selectedName + '”.';
            return;
          }
          if (searchNote) searchNote.textContent = matches.length + ' ' + (strings.results || 'fișiere găsite') + ' în „' + selectedName + '”.';
          var list = document.createElement('ul');
          list.className = 'pbv-mol-results-list';
          matches.forEach(function (file) {
            var item = document.createElement('li');
            var link = document.createElement('a');
            link.href = file.webViewLink || ('https://drive.google.com/open?id=' + encodeURIComponent(file.id));
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            link.textContent = file.name || 'Document fără nume';
            var meta = document.createElement('span');
            meta.className = 'pbv-mol-result-date';
            if (file.modifiedTime) {
              var date = new Date(file.modifiedTime);
              if (!isNaN(date.getTime())) meta.textContent = date.toLocaleDateString('ro-RO');
            }
            item.appendChild(link);
            if (meta.textContent) item.appendChild(meta);
            list.appendChild(item);
          });
          results.appendChild(list);
        }).catch(function () {
          if (searchNote) searchNote.textContent = strings.apiError || 'Nu s-a putut accesa Google Drive API.';
        });
      });
    }
  });
});
