<?php
/**
 * Admin editor for the Google Drive folder catalog.
 *
 * @package PBV_Site_Enhancements
 */

if (!defined('ABSPATH')) {
    exit;
}

final class PBV_Drive_Catalog_Manager {
    private $file;

    public function __construct($file) {
        $this->file = $file;
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_post_pbv_drive_catalog_save', array($this, 'save_catalog'));
        add_action('wp_ajax_pbv_drive_catalog_test', array($this, 'test_folder'));
        add_action('wp_ajax_pbv_drive_catalog_delete', array($this, 'delete_folder'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function admin_menu() {
        add_submenu_page(
            'pbv-formulare',
            'Foldere Google Drive',
            'Foldere Google Drive',
            'manage_options',
            'pbv-drive-folder-manager',
            array($this, 'render_page')
        );
    }

    public function enqueue_assets($hook) {
        if (!isset($_GET['page']) || sanitize_key(wp_unslash($_GET['page'])) !== 'pbv-drive-folder-manager') {
            return;
        }
        wp_enqueue_script(
            'pbv-drive-catalog-admin',
            plugin_dir_url(dirname(__DIR__) . '/pbv-site-enhancements.php') . 'assets/drive-catalog-admin.js',
            array(),
            '1.4.0',
            true
        );
        wp_localize_script('pbv-drive-catalog-admin', 'pbvDriveCatalogAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('pbv_drive_catalog_test'),
            'deleteNonce' => wp_create_nonce('pbv_drive_catalog_delete'),
            'adminUrl' => admin_url('admin.php?page=pbv-drive-folder-manager'),
            'strings' => array(
                'noApiKey' => 'Cheia API nu este configurată. Deschideți Setări → Monitorul Oficial Local și configurați cheia Google Drive API v3.',
                'unavailable' => 'Testul nu a putut verifica folderul. Confirmați că API-ul Drive este activat, ID-ul este accesibil pentru cheia configurată și restricțiile acesteia permit domeniul site-ului.',
            ),
        ));
    }

    private function folder_path_map() {
        $read = $this->read_document();
        if (is_wp_error($read)) {
            return array();
        }
        $resolved = self::resolve_duplicates($read['document']['folders']);
        $map = array();
        foreach ($resolved['folders'] as $folder) {
            $map[implode("\x1f", array_values($folder['segments']))] = (string) $folder['id'];
        }
        return $map;
    }

    private static function modified_key($modified) {
        if (!is_string($modified)) {
            return '';
        }
        $modified = trim($modified);
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/D', $modified, $parts)) {
            $year = (int) $parts[1];
            $month = (int) $parts[2];
            $day = (int) $parts[3];
            $hour = (int) $parts[4];
            $minute = (int) $parts[5];
            if (checkdate($month, $day, $year) && $hour <= 23 && $minute <= 59) {
                return $modified . ':00';
            }
        }
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/D', $modified, $parts)) {
            $year = (int) $parts[1];
            $month = (int) $parts[2];
            $day = (int) $parts[3];
            $hour = (int) $parts[4];
            $minute = (int) $parts[5];
            $second = (int) $parts[6];
            if (checkdate($month, $day, $year) && $hour <= 23 && $minute <= 59 && $second <= 59) {
                return sprintf('%04d-%02d-%02d %02d:%02d:%02d', $year, $month, $day, $hour, $minute, $second);
            }
        }
        if (preg_match('/^(\d{2})\.(\d{2})\.(\d{4}) (\d{2}):(\d{2})$/D', $modified, $parts)) {
            $day = (int) $parts[1];
            $month = (int) $parts[2];
            $year = (int) $parts[3];
            $hour = (int) $parts[4];
            $minute = (int) $parts[5];
            if (checkdate($month, $day, $year) && $hour <= 23 && $minute <= 59) {
                return sprintf('%04d-%02d-%02d %02d:%02d:00', $year, $month, $day, $hour, $minute);
            }
        }
        try {
            $timestamp = new DateTimeImmutable($modified, new DateTimeZone('UTC'));
            return $timestamp->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (Exception $exception) {
            return '';
        }
    }

    /** Resolve repeated logical paths using persisted Drive modification timestamps. */
    public static function resolve_duplicates($folders) {
        $resolved = array();
        $indexes = array();
        $stats = array('duplicates' => 0, 'ties' => 0, 'unranked' => 0);
        foreach ((array) $folders as $folder) {
            if (!is_array($folder) || empty($folder['segments']) || !is_array($folder['segments']) || empty($folder['id'])) {
                continue;
            }
            $segments = array_values(array_map('strval', $folder['segments']));
            $key = implode("\x1f", $segments);
            if (!isset($indexes[$key])) {
                $indexes[$key] = count($resolved);
                $resolved[] = $folder;
                continue;
            }
            $stats['duplicates']++;
            $existing_index = $indexes[$key];
            $existing_time = self::modified_key(isset($resolved[$existing_index]['modified']) ? $resolved[$existing_index]['modified'] : '');
            $candidate_time = self::modified_key(isset($folder['modified']) ? $folder['modified'] : '');
            if ($existing_time !== '' && $candidate_time !== '') {
                if (strcmp($candidate_time, $existing_time) > 0) {
                    $resolved[$existing_index] = $folder;
                } elseif ($candidate_time === $existing_time) {
                    // Equal timestamps do not identify a unique latest folder; retain first source row.
                    $stats['ties']++;
                }
            } elseif ($existing_time === '' && $candidate_time !== '') {
                $resolved[$existing_index] = $folder;
            } else {
                // No timestamp is fabricated. Keep first source row when both are missing or tied.
                $stats['unranked']++;
            }
        }
        return array('folders' => array_values($resolved), 'stats' => $stats);
    }

    private function read_document() {
        if (!is_readable($this->file)) {
            return new WP_Error('pbv_drive_catalog_read', 'Catalogul Google Drive nu poate fi citit. Verificați fișierul data/google-drive-folders.json din plugin.');
        }
        $raw = file_get_contents($this->file);
        if ($raw === false) {
            return new WP_Error('pbv_drive_catalog_read', 'Nu s-a putut citi catalogul Google Drive.');
        }
        $decoded = json_decode(preg_replace('/^\xEF\xBB\xBF/', '', $raw), true);
        if (!is_array($decoded) || !isset($decoded['folders']) || !is_array($decoded['folders'])) {
            return new WP_Error('pbv_drive_catalog_json', 'Catalogul nu are structura JSON așteptată { "folders": [...] }. Nu salvați până când JSON-ul nu este reparat.');
        }
        foreach ($decoded['folders'] as $folder) {
            if (!is_array($folder) || empty($folder['segments']) || !is_array($folder['segments']) || empty($folder['id'])) {
                return new WP_Error('pbv_drive_catalog_entry', 'Catalogul conține o intrare fără cale sau ID; încărcarea managerului a fost oprită pentru a preveni pierderea datelor.');
            }
        }
        $resolved = self::resolve_duplicates($decoded['folders']);
        return array('document' => $decoded, 'raw' => $raw, 'duplicate_stats' => $resolved['stats']);
    }

    private function root_order() {
        return array(
            '1Statut', '2Regul',
            '3PHCL', '3ArhPHCL', '3HCL', '3ArhHCL',
            '4PDPr', '4ArhPDPr', '4DPr', '4ArhDPr',
            '51PrB', '52Datorie', '53Buget', '54Bilant',
            '61Refuz', '62PrPrH', '63PrANorm', '64PVSed', '65IntPb', '66Minute', '67Avere', '68Interese', '69DCasat', '6101Ziar', '6102VinzTeren', '6103Licitatii', '6104Convoc', '6106Concurs',
            '7Societati', '71SPPS', '72Constructii', '73Spatii',
        );
    }

    private function make_tree($folders) {
        $tree = array();
        foreach ($folders as $index => $folder) {
            $branch =& $tree;
            foreach (array_values($folder['segments']) as $segment) {
                $segment = (string) $segment;
                if (!isset($branch[$segment])) {
                    $branch[$segment] = array('name' => $segment, 'row' => null, 'children' => array());
                }
                $branch =& $branch[$segment]['children'];
            }
            unset($branch);
            $branch =& $tree;
            foreach (array_values($folder['segments']) as $segment) {
                $branch =& $branch[$segment];
            }
            $branch['row'] = $index;
            unset($branch);
        }
        return $tree;
    }

    private function rekey_nodes($nodes, $names) {
        $sorted = array();
        foreach ($names as $name) {
            if (isset($nodes[$name])) {
                $sorted[$name] = $nodes[$name];
            }
        }
        return $sorted;
    }

    private function sort_tree_children(&$nodes, $depth) {
        $names = array_keys($nodes);
        if ($depth === 0) {
            $rank = array_flip($this->root_order());
            $fallback = count($rank);
            usort($names, function ($first, $second) use ($rank, $fallback) {
                $first_rank = isset($rank[$first]) ? $rank[$first] : $fallback;
                $second_rank = isset($rank[$second]) ? $rank[$second] : $fallback;
                return $first_rank === $second_rank ? strnatcasecmp($first, $second) : ($first_rank <=> $second_rank);
            });
        } else {
            usort($names, function ($first, $second) {
                $first_year = preg_match('/^\d{4}$/', (string) $first) === 1;
                $second_year = preg_match('/^\d{4}$/', (string) $second) === 1;
                if ($first_year && $second_year) {
                    return (int) $second <=> (int) $first;
                }
                if ($first_year !== $second_year) {
                    return $first_year ? -1 : 1;
                }
                $natural = strnatcasecmp($first, $second);
                return $natural !== 0 ? $natural : strcmp($first, $second);
            });
        }
        $nodes = $this->rekey_nodes($nodes, $names);
        foreach ($nodes as &$node) {
            if (!empty($node['children'])) {
                $this->sort_tree_children($node['children'], $depth + 1);
            }
        }
        unset($node);
    }

    private function ordered_rows($folders) {
        $rank = array_flip($this->root_order());
        $indexed = array();
        foreach ($folders as $index => $folder) {
            $segments = array_values(isset($folder['segments']) && is_array($folder['segments']) ? $folder['segments'] : array());
            $indexed[] = array('index' => $index, 'folder' => $folder, 'segments' => $segments, 'depth' => max(0, count($segments) - 1));
        }
        usort($indexed, function ($first, $second) use ($rank) {
            $left = $first['segments'];
            $right = $second['segments'];
            $limit = min(count($left), count($right));
            for ($i = 0; $i < $limit; $i++) {
                if ($left[$i] === $right[$i]) {
                    continue;
                }
                if ($i === 0) {
                    $left_rank = isset($rank[$left[$i]]) ? $rank[$left[$i]] : count($rank);
                    $right_rank = isset($rank[$right[$i]]) ? $rank[$right[$i]] : count($rank);
                    if ($left_rank !== $right_rank) {
                        return $left_rank <=> $right_rank;
                    }
                }
                $left_year = preg_match('/^\d{4}$/', (string) $left[$i]);
                $right_year = preg_match('/^\d{4}$/', (string) $right[$i]);
                if ($left_year && $right_year) {
                    return (int) $right[$i] <=> (int) $left[$i];
                }
                if ((bool) $left_year !== (bool) $right_year) {
                    return $left_year ? -1 : 1;
                }
                $natural = strnatcasecmp($left[$i], $right[$i]);
                return $natural !== 0 ? $natural : strcmp($left[$i], $right[$i]);
            }
            if (count($left) !== count($right)) {
                return count($left) <=> count($right);
            }
            return $first['index'] <=> $second['index'];
        });
        return $indexed;
    }

    private function parent_suggestions($folders) {
        $paths = array('MofL' => 'Rădăcina MofL');
        foreach ($folders as $folder) {
            $segments = array_values($folder['segments']);
            for ($length = 1; $length <= count($segments); $length++) {
                $value = implode(' / ', array_slice($segments, 0, $length));
                if (!isset($paths[$value])) {
                    $paths[$value] = 'MofL / ' . $value;
                }
            }
        }
        return $paths;
    }

    public function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a administra catalogul Google Drive.', 403);
        }
        $read = $this->read_document();
        ?>
        <div class="wrap">
            <h1>Manager foldere Google Drive – Monitorul Oficial Local</h1>
            <p>Completați <strong>Parinte</strong>, <strong>Subfolder</strong> (opțional) și <strong>ID folder</strong>. Parinte este calea folderului țintă dacă Subfolder este gol; altfel ID-ul aparține copilului indicat. Exemplu pentru an: Parinte „3ArhHCL”, Subfolder „2026”. Pentru un folder nou direct sub rădăcina MofL, Parinte „MofL”, Subfolder cu numele nou.</p>
            <p><strong>Test</strong> trimite o cerere read-only prin serverul WordPress la Google Drive API. Verifică ID-ul, numele și tipul folderului, verifică părintele când acesta este în catalog și preia data modificării. Pentru foldere direct sub rădăcina MofL, ID-ul rădăcinii nu este în catalog, deci testul nu poate confirma relația cu rădăcina. Necesită cheia API Google Drive configurată la Setări → Monitorul Oficial Local și un folder accesibil cu cheia respectivă. Nu se schimbă nimic în Drive. Modificările se salvează în JSON-ul pluginului; faceți backup înainte de actualizarea pluginului.</p>
            <?php $this->render_notice(); ?>
            <?php if (is_wp_error($read)) : ?>
                <div class="notice notice-error"><p><?php echo esc_html($read->get_error_message()); ?></p></div>
            <?php else :
                $folders = $read['document']['folders'];
                $rows = $this->ordered_rows($folders);
                $next_index = count($folders);
                $year_subfolders = 0;
                foreach ($folders as $folder_entry) {
                    $segments = array_values($folder_entry['segments']);
                    if (count($segments) > 1 && preg_match('/^\d{4}$/', (string) end($segments))) {
                        $year_subfolders++;
                    }
                }
                ?>
                <?php if (!empty($read['duplicate_stats']['duplicates'])) : ?>
                    <div class="notice notice-info"><p><?php echo esc_html((string) $read['duplicate_stats']['duplicates']); ?> căi duplicate există în JSON; sunt afișate toate pentru revizuire. Apăsați Test pentru fiecare intrare duplicată. La salvare se păstrează folderul cu timpul „modified” cel mai recent returnat de Drive; pentru timpi egali se păstrează prima intrare.</p></div>
                <?php endif; ?>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="pbv-drive-catalog-form">
                    <input type="hidden" name="action" value="pbv_drive_catalog_save">
                    <input type="hidden" name="pbv_catalog_hash" value="<?php echo esc_attr(hash('sha256', $read['raw'])); ?>">
                    <?php wp_nonce_field('pbv_drive_catalog_save', 'pbv_drive_catalog_nonce'); ?>
                    <datalist id="pbv-drive-parent-options">
                        <?php foreach ($this->parent_suggestions($folders) as $value => $label) : ?>
                            <option value="<?php echo esc_attr($value); ?>" label="<?php echo esc_attr($label); ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                    <div style="overflow-x:auto;">
                        <table class="widefat striped" id="pbv-drive-catalog-table">
                            <thead><tr><th scope="col">Șterge</th><th scope="col">Parinte</th><th scope="col">Subfolder (opțional)</th><th scope="col">ID folder Google Drive</th><th scope="col">Test</th></tr></thead>
                            <tbody data-pbv-folder-rows>
                            <?php foreach ($rows as $row) :
                                $this->render_row($row['index'], $row['folder']);
                            endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <p><button type="button" class="button" data-pbv-add-folder>Adaugă un folder</button></p>
                    <template data-pbv-folder-template><?php $this->render_row('__INDEX__', null); ?></template>
                    <p>
                        <?php submit_button('Salvează modificările', 'primary', 'submit', false); ?>
                        <a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=pbv-drive-folder-manager')); ?>">Renunță la modificări</a>
                    </p>
                </form>
                <p class="description">Catalog: <?php echo esc_html((string) count($folders)); ?> intrări, inclusiv <?php echo esc_html((string) $year_subfolders); ?> subfoldere-an. Programul păstrează ordinea fixă a categoriilor, afișează anii descrescător și celelalte subfoldere alfabetic/natural. Data modificării este obținută din API la Test și păstrată numai ca metadată internă; nu există câmp editabil pentru dată sau ordine.</p>
                <script>window.pbvDriveCatalogNextIndex = <?php echo (int) $next_index; ?>;</script>
            <?php endif; ?>
        </div>
        <?php
    }

    private function render_row($index, $folder) {
        $index_string = (string) $index;
        $parent_id = 'pbv-drive-parent-' . $index_string;
        $child_id = 'pbv-drive-subfolder-' . $index_string;
        $drive_id = 'pbv-drive-id-' . $index_string;
        $segments = $folder && isset($folder['segments']) ? array_values($folder['segments']) : array();
        if (!$segments) {
            $parent = '';
            $subfolder = '';
            $id = '';
        } elseif (count($segments) === 1) {
            $parent = implode(' / ', $segments);
            $subfolder = '';
            $id = $folder['id'];
        } else {
            $parent = implode(' / ', array_slice($segments, 0, -1));
            $subfolder = (string) end($segments);
            $id = $folder['id'];
        }
        $modified = $folder && isset($folder['modified']) ? (string) $folder['modified'] : '';
        ?>
        <tr data-pbv-folder-row<?php if ($folder && $segments) : ?> data-pbv-index="<?php echo esc_attr($index_string); ?>" data-pbv-saved-id="<?php echo esc_attr((string) $folder['id']); ?>" data-pbv-path="<?php echo esc_attr(implode(' / ', $segments)); ?>"<?php endif; ?>>
            <td><button type="button" class="button-link button-link-delete" data-pbv-delete-folder title="Șterge" aria-label="Șterge folderul din catalog" style="color:#b32d2e;"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button></td>
            <td><label class="screen-reader-text" for="<?php echo esc_attr($parent_id); ?>">Parinte</label><input class="regular-text" type="text" list="pbv-drive-parent-options" id="<?php echo esc_attr($parent_id); ?>" name="folders[<?php echo esc_attr($index_string); ?>][parent]" value="<?php echo esc_attr($parent); ?>" placeholder="MofL sau calea părintelui"></td>
            <td><label class="screen-reader-text" for="<?php echo esc_attr($child_id); ?>">Subfolder (opțional)</label><input class="regular-text" type="text" id="<?php echo esc_attr($child_id); ?>" name="folders[<?php echo esc_attr($index_string); ?>][subfolder]" value="<?php echo esc_attr($subfolder); ?>" placeholder="Ex.: 2026"></td>
            <td><label class="screen-reader-text" for="<?php echo esc_attr($drive_id); ?>">ID folder Google Drive</label><input class="regular-text" type="text" id="<?php echo esc_attr($drive_id); ?>" name="folders[<?php echo esc_attr($index_string); ?>][id]" value="<?php echo esc_attr($id); ?>" placeholder="ID-ul folderului"><input type="hidden" name="folders[<?php echo esc_attr($index_string); ?>][modified]" value="<?php echo esc_attr($modified); ?>" data-pbv-folder-modified><input type="hidden" name="folders[<?php echo esc_attr($index_string); ?>][tested]" value="0" data-pbv-folder-tested><input type="hidden" name="folders[<?php echo esc_attr($index_string); ?>][proof]" value="" data-pbv-folder-proof></td>
            <td><button type="button" class="button" data-pbv-test-folder>Test</button> <span class="description" data-pbv-test-result role="status" aria-live="polite"></span></td>
        </tr>
        <?php
    }

    private function render_notice() {
        $key = isset($_GET['pbv_manager_notice']) ? sanitize_key(wp_unslash($_GET['pbv_manager_notice'])) : '';
        $notices = array(
            'deleted' => array('success', 'Folderul a fost șters din catalogul JSON.'),
            'saved' => array('success', 'Catalogul Google Drive a fost salvat. Categoriile și subfolderele vor fi ordonate automat.'),
            'invalid' => array('error', 'Modificările nu au fost salvate. Verificați Parinte, Subfolder și formatul ID-ului; catalogul anterior a rămas intact.'),
            'duplicate' => array('error', 'Calea apare de mai multe ori, dar nu există date „modified” obținute prin Test pentru toate ID-urile. Testați toate folderele duplicate și salvați din nou.'),
            'id_reuse' => array('error', 'Același ID Google Drive este asociat unor căi diferite. Verificați Parinte, Subfolder și ID folder.'),
            'test_required' => array('error', 'Pentru un folder nou sau schimbat, apăsați Test și așteptați confirmarea API înainte de salvare.'),
            'parent' => array('error', 'Parintele indicat nu există în catalogul trimis. Salvați mai întâi folderul părinte sau selectați calea existentă din sugestii.'),
            'conflict' => array('warning', 'Catalogul a fost schimbat după ce ați deschis pagina. Reîncărcați înainte de salvare pentru a nu suprascrie actualizări recente.'),
            'write' => array('error', 'Nu s-a putut scrie catalogul. Verificați permisiunile de scriere ale directorului pluginului.'),
        );
        if (isset($notices[$key])) {
            echo '<div class="notice notice-' . esc_attr($notices[$key][0]) . ' is-dismissible"><p>' . esc_html($notices[$key][1]) . '</p></div>';
        }
    }

    private function parse_path_segments($value, $allow_root = false) {
        $value = trim(sanitize_text_field((string) $value));
        if ($value === '') {
            return $allow_root ? array() : false;
        }
        $raw_segments = array_map('trim', explode('/', $value));
        if (in_array('', $raw_segments, true)) {
            return false;
        }
        if (isset($raw_segments[0]) && strcasecmp($raw_segments[0], 'MofL') === 0) {
            array_shift($raw_segments);
        }
        if (!$raw_segments) {
            return $allow_root ? array() : false;
        }
        $segments = array();
        foreach ($raw_segments as $segment) {
            $clean = sanitize_text_field($segment);
            if ($clean === '' || $clean === '.' || $clean === '..' || $clean !== $segment || strlen($clean) > 255) {
                return false;
            }
            $segments[] = $clean;
        }
        return $segments;
    }

    private function redirect($notice) {
        wp_safe_redirect(add_query_arg('pbv_manager_notice', $notice, admin_url('admin.php?page=pbv-drive-folder-manager')));
        exit;
    }

    private function drive_modified_value($modified) {
        try {
            $date = new DateTimeImmutable((string) $modified, new DateTimeZone('UTC'));
            return $date->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (Exception $exception) {
            return '';
        }
    }

    private function test_proof($id, $segments, $modified) {
        return hash_hmac('sha256', $id . "\x1f" . implode("\x1f", $segments) . "\x1f" . $modified, wp_salt('auth'));
    }

    public function delete_folder() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Nu aveți permisiunea de a șterge foldere din catalog.'), 403);
        }
        check_ajax_referer('pbv_drive_catalog_delete', 'nonce');
        $index_raw = isset($_POST['index']) ? sanitize_text_field(wp_unslash($_POST['index'])) : '';
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        $hash = isset($_POST['hash']) ? sanitize_text_field(wp_unslash($_POST['hash'])) : '';
        if (!ctype_digit($index_raw) || !preg_match('/^[A-Za-z0-9_-]{5,200}$/D', $id)) {
            wp_send_json_error(array('message' => 'Cerere de ștergere invalidă.'), 400);
        }
        $read = $this->read_document();
        if (is_wp_error($read)) {
            wp_send_json_error(array('message' => $read->get_error_message()), 400);
        }
        if (!hash_equals(hash('sha256', $read['raw']), $hash)) {
            wp_send_json_error(array('message' => 'Catalogul a fost schimbat după ce ați deschis pagina. Reîncărcați pagina și încercați din nou.'), 409);
        }
        $folders = array_values($read['document']['folders']);
        $index = (int) $index_raw;
        if (!isset($folders[$index]) || (string) $folders[$index]['id'] !== $id) {
            wp_send_json_error(array('message' => 'Intrarea nu mai există în catalog. Reîncărcați pagina.'), 404);
        }
        $target = array_values(array_map('strval', $folders[$index]['segments']));
        $twin = false;
        foreach ($folders as $other_index => $other) {
            if ($other_index !== $index && array_values(array_map('strval', $other['segments'])) === $target) {
                $twin = true;
                break;
            }
        }
        $kept = array();
        $removed = 0;
        foreach ($folders as $other_index => $other) {
            $segments = array_values(array_map('strval', $other['segments']));
            // A duplicate path keeps its twin and descendants; otherwise the entry and all its subfolders go.
            $is_target = $twin ? ($other_index === $index) : (array_slice($segments, 0, count($target)) === $target);
            if ($is_target) {
                $removed++;
                continue;
            }
            $kept[] = $other;
        }
        $document = $read['document'];
        $document['folders'] = $kept;
        $document['folder_count'] = count($kept);
        $saved = $this->write_document($document, $hash);
        if (is_wp_error($saved)) {
            wp_send_json_error(array('message' => $saved->get_error_message()), 409);
        }
        wp_send_json_success(array('removed' => $removed, 'message' => 'Șters din catalog: ' . $removed . ' intrare(i).'));
    }

    /**
     * Check whether $child_id is a direct, non-trashed subfolder of $parent_id by listing the parent's folders.
     * Returns true/false, or null when the listing could not be read (no access, API error, too many pages).
     */
    private function folder_is_child_of($api_key, $parent_id, $child_id) {
        if (!preg_match('/^[A-Za-z0-9_-]{5,200}$/D', (string) $parent_id)) {
            return null;
        }
        $token = '';
        for ($page = 0; $page < 10; $page++) {
            $args = array(
                'key' => $api_key,
                'q' => "'" . $parent_id . "' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false",
                'fields' => 'nextPageToken,files(id)',
                'pageSize' => 1000,
                'supportsAllDrives' => 'true',
                'includeItemsFromAllDrives' => 'true',
            );
            if ($token !== '') {
                $args['pageToken'] = $token;
            }
            $response = wp_remote_get(add_query_arg($args, 'https://www.googleapis.com/drive/v3/files'), array(
                'timeout' => 15,
                'redirection' => 0,
                'headers' => array('Referer' => home_url('/')),
            ));
            if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
                return null;
            }
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if (!is_array($data) || !isset($data['files']) || !is_array($data['files'])) {
                return null;
            }
            foreach ($data['files'] as $file) {
                if (isset($file['id']) && (string) $file['id'] === (string) $child_id) {
                    return true;
                }
            }
            $token = isset($data['nextPageToken']) ? (string) $data['nextPageToken'] : '';
            if ($token === '') {
                return false;
            }
        }
        return null;
    }

    public function test_folder() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Nu aveți permisiunea de a testa folderele.'), 403);
        }
        check_ajax_referer('pbv_drive_catalog_test', 'nonce');
        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        $segments_raw = isset($_POST['segments']) ? json_decode(wp_unslash($_POST['segments']), true) : null;
        if (!preg_match('/^[A-Za-z0-9_-]{5,200}$/D', $id) || !is_array($segments_raw) || !$segments_raw || count($segments_raw) > 12) {
            wp_send_json_error(array('message' => 'ID sau cale invalidă.'), 400);
        }
        $segments = array();
        foreach ($segments_raw as $segment) {
            $clean = sanitize_text_field((string) $segment);
            if ($clean === '' || $clean !== (string) $segment || $clean === '.' || $clean === '..' || strpos($clean, '/') !== false) {
                wp_send_json_error(array('message' => 'Calea conține un segment invalid.'), 400);
            }
            $segments[] = $clean;
        }
        $api_key = trim((string) get_option('pbv_drive_api_key', ''));
        if ($api_key === '') {
            wp_send_json_error(array('message' => 'Cheia API Google Drive nu este configurată. Deschideți Setări → Monitorul Oficial Local.'), 400);
        }
        if (count($segments) > 1) {
            $read = $this->read_document();
            if (is_wp_error($read)) {
                wp_send_json_error(array('message' => $read->get_error_message()), 400);
            }
            $parent_segments = array_slice($segments, 0, -1);
            $parent_id = '';
            foreach (self::resolve_duplicates($read['document']['folders'])['folders'] as $entry) {
                if (array_values($entry['segments']) === $parent_segments) {
                    $parent_id = (string) $entry['id'];
                    break;
                }
            }
            if ($parent_id === '') {
                wp_send_json_error(array('message' => 'Folderul părinte nu există în catalog. Salvați mai întâi părintele.'), 400);
            }
        }
        $url = add_query_arg(array(
            'key' => $api_key,
            'fields' => 'id,name,mimeType,modifiedTime,parents',
            'supportsAllDrives' => 'true',
        ), 'https://www.googleapis.com/drive/v3/files/' . rawurlencode($id));
        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'redirection' => 0,
            'headers' => array('Referer' => home_url('/')),
        ));
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Cererea către Google Drive a eșuat. Verificați accesul serverului la API.'), 502);
        }
        $status = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($body)) {
            wp_send_json_error(array('message' => 'Google Drive API nu a confirmat folderul (HTTP ' . $status . '). Verificați cheia, accesul și ID-ul.'), 502);
        }
        if (!isset($body['id'], $body['name'], $body['mimeType'], $body['modifiedTime']) || (string) $body['id'] !== $id) {
            wp_send_json_error(array('message' => 'Răspunsul Google Drive nu conține datele necesare verificării.'), 502);
        }
        if ($body['mimeType'] !== 'application/vnd.google-apps.folder') {
            wp_send_json_error(array('message' => 'ID-ul aparține unui fișier, nu unui folder.'), 400);
        }
        if ((string) $body['name'] !== (string) end($segments)) {
            wp_send_json_error(array('message' => 'Numele folderului din Drive nu corespunde cu ultimul segment al căii.'), 400);
        }
        if (isset($parent_id)) {
            $actual_parents = (isset($body['parents']) && is_array($body['parents'])) ? array_map('strval', $body['parents']) : array();
            if (!in_array($parent_id, $actual_parents, true)) {
                // Drive omits `parents` for API-key requests when the parent is not visible to the key, so fall back to listing the parent's subfolders.
                $listed = $this->folder_is_child_of($api_key, $parent_id, $id);
                if ($listed === null) {
                    wp_send_json_error(array('message' => 'Drive nu a returnat părintele folderului, iar lista subfolderelor părintelui nu a putut fi citită. Verificați că folderul părinte (' . implode(' / ', $parent_segments) . ') este partajat prin link (Oricine are linkul - Vizualizator).'), 400);
                }
                if ($listed === false) {
                    $actual_path = '';
                    foreach ((array) $read['document']['folders'] as $known) {
                        if (isset($known['id'], $known['segments']) && in_array((string) $known['id'], $actual_parents, true)) {
                            $actual_path = implode(' / ', array_values($known['segments']));
                            break;
                        }
                    }
                    $detail = ' Părinte așteptat: ' . implode(' / ', $parent_segments) . ' (' . $parent_id . ').';
                    $detail .= $actual_parents
                        ? ' Părinte real în Drive: ' . implode(', ', $actual_parents) . ($actual_path !== '' ? ' = ' . $actual_path : ' (negăsit în catalog)') . '.'
                        : ' Folderul nu apare printre subfolderele părintelui; dacă există în Drive, partajați-l prin link sau mutați-l în părinte.';
                    wp_send_json_error(array('message' => 'Folderul există, dar nu este copilul părintelui ales.' . $detail), 400);
                }
            }
        }
        $modified = $this->drive_modified_value($body['modifiedTime']);
        if ($modified === '') {
            wp_send_json_error(array('message' => 'Google Drive API nu a returnat o dată validă de modificare.'), 502);
        }
        wp_send_json_success(array(
            'modified' => $modified,
            'proof' => $this->test_proof($id, $segments, $modified),
            'message' => 'Verificat cu succes prin Google Drive API; data reală a fost preluată pentru deduplicare.',
        ));
    }

    public function save_catalog() {
        if (!current_user_can('manage_options')) {
            wp_die('Nu aveți permisiunea de a salva catalogul Google Drive.', 403);
        }
        check_admin_referer('pbv_drive_catalog_save', 'pbv_drive_catalog_nonce');
        $read = $this->read_document();
        if (is_wp_error($read)) {
            $this->redirect('invalid');
        }
        $expected_hash = isset($_POST['pbv_catalog_hash']) ? sanitize_text_field(wp_unslash($_POST['pbv_catalog_hash'])) : '';
        $submitted = isset($_POST['folders']) ? wp_unslash($_POST['folders']) : array();
        if (!is_array($submitted) || !hash_equals(hash('sha256', $read['raw']), $expected_hash)) {
            $this->redirect('conflict');
        }
        $old_folders = $read['document']['folders'];
        foreach ($old_folders as $existing_index => $existing_folder) {
            if (!isset($submitted[$existing_index]) || !is_array($submitted[$existing_index])) {
                $this->redirect('invalid');
            }
        }

        $folders = array();
        $seen_paths = array();
        $seen_ids = array();
        foreach ($submitted as $index => $row) {
            if (!is_array($row)) {
                $this->redirect('invalid');
            }
            $index = (string) $index;
            $is_existing = ctype_digit($index) && isset($old_folders[(int) $index]);
            $parent_raw = isset($row['parent']) ? trim(sanitize_text_field($row['parent'])) : '';
            $child_raw = isset($row['subfolder']) ? trim(sanitize_text_field($row['subfolder'])) : '';
            $id = isset($row['id']) ? trim(sanitize_text_field($row['id'])) : '';
            if ($id === '' && $child_raw === '' && $parent_raw === '' && !$is_existing) {
                continue;
            }
            if ($id === '' || !preg_match('/^[A-Za-z0-9_-]{5,200}$/D', $id)) {
                $this->redirect('invalid');
            }
            $parent_segments = $this->parse_path_segments($parent_raw, true);
            if ($parent_segments === false) {
                $this->redirect('invalid');
            }
            $child = '';
            if ($child_raw !== '') {
                $child = sanitize_text_field($child_raw);
                if ($child === '' || $child !== $child_raw || $child === '.' || $child === '..' || strpos($child, '/') !== false || strlen($child) > 255) {
                    $this->redirect('invalid');
                }
            }
            if (!$parent_segments && $child === '') {
                $this->redirect('invalid');
            }
            $segments = $parent_segments;
            if ($child !== '') {
                $segments[] = $child;
            }
            if (!$segments || count($segments) > 12) {
                $this->redirect('invalid');
            }
            $path_key = implode("\x1f", $segments);
            if (isset($seen_ids[$id]) && $seen_ids[$id] !== $path_key) {
                $this->redirect('id_reuse');
            }
            $seen_ids[$id] = $path_key;
            $seen_paths[$path_key] = true;

            $folder = $is_existing ? $old_folders[(int) $index] : array();
            $same_source_folder = $is_existing
                && isset($folder['segments'])
                && array_values($folder['segments']) === $segments
                && isset($folder['id'])
                && (string) $folder['id'] === $id;
            $folder['segments'] = $segments;
            $folder['id'] = $id;
            if (!$same_source_folder) {
                $tested = isset($row['tested']) && (string) $row['tested'] === '1';
                $modified = isset($row['modified']) ? sanitize_text_field((string) $row['modified']) : '';
                $proof = isset($row['proof']) ? sanitize_text_field((string) $row['proof']) : '';
                $modified_value = $tested ? $this->drive_modified_value($modified) : '';
                if (!$tested || $modified_value === '' || !hash_equals($this->test_proof($id, $segments, $modified_value), $proof)) {
                    $this->redirect('test_required');
                }
                $folder['modified'] = $modified_value;
            } elseif (isset($row['tested']) && (string) $row['tested'] === '1') {
                $modified = isset($row['modified']) ? sanitize_text_field((string) $row['modified']) : '';
                $proof = isset($row['proof']) ? sanitize_text_field((string) $row['proof']) : '';
                $modified_value = $this->drive_modified_value($modified);
                if ($modified_value === '' || !hash_equals($this->test_proof($id, $segments, $modified_value), $proof)) {
                    $this->redirect('test_required');
                }
                $folder['modified'] = $modified_value;
            }
            // Ordering is computed by the program. Remove any legacy manual-order value on the next save.
            unset($folder['order']);
            $folder['_pbv_tested'] = isset($row['tested']) && (string) $row['tested'] === '1';
            $folders[] = $folder;
        }

        foreach ($folders as $folder) {
            $segments = array_values($folder['segments']);
            if (count($segments) > 1) {
                $parent_key = implode("\x1f", array_slice($segments, 0, -1));
                if (!isset($seen_paths[$parent_key])) {
                    $this->redirect('parent');
                }
            }
        }

        $path_counts = array();
        foreach ($folders as $folder) {
            $key = implode("\x1f", array_values($folder['segments']));
            $path_counts[$key] = isset($path_counts[$key]) ? $path_counts[$key] + 1 : 1;
        }
        foreach ($folders as $folder) {
            $key = implode("\x1f", array_values($folder['segments']));
            if ($path_counts[$key] < 2) {
                continue;
            }
            if (empty($folder['_pbv_tested']) || empty($folder['modified'])) {
                $this->redirect('duplicate');
            }
        }

        $resolved = self::resolve_duplicates($folders);
        $folders = $resolved['folders'];
        foreach ($folders as &$folder) {
            unset($folder['_pbv_tested']);
        }
        unset($folder);

        $document = $read['document'];
        $document['folders'] = $folders;
        $document['folder_count'] = count($folders);
        $saved = $this->write_document($document, $expected_hash);
        if (is_wp_error($saved)) {
            $this->redirect($saved->get_error_code() === 'pbv_drive_catalog_conflict' ? 'conflict' : 'write');
        }
        $this->redirect('saved');
    }

    private function write_document($document, $expected_hash) {
        $directory = dirname($this->file);
        if (!is_writable($directory)) {
            return new WP_Error('pbv_drive_catalog_write', 'Directorul catalogului nu este inscriptibil.');
        }
        $lock_file = $this->file . '.lock';
        $lock = @fopen($lock_file, 'c');
        if (!$lock || !flock($lock, LOCK_EX)) {
            if (is_resource($lock)) {
                fclose($lock);
            }
            return new WP_Error('pbv_drive_catalog_write', 'Nu s-a putut bloca fișierul catalogului.');
        }
        $temporary = '';
        try {
            $current = file_get_contents($this->file);
            if ($current === false || !hash_equals(hash('sha256', $current), $expected_hash)) {
                return new WP_Error('pbv_drive_catalog_conflict', 'Catalogul a fost schimbat în timpul salvării.');
            }
            $json = wp_json_encode($document, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) {
                return new WP_Error('pbv_drive_catalog_write', 'JSON-ul nu a putut fi codificat.');
            }
            $temporary = tempnam($directory, '.pbv-drive-catalog-');
            if (!$temporary || dirname($temporary) !== $directory || file_put_contents($temporary, $json . PHP_EOL, LOCK_EX) === false) {
                return new WP_Error('pbv_drive_catalog_write', 'Nu s-a putut crea fișierul temporar.');
            }
            $mode = @fileperms($this->file);
            if ($mode !== false) {
                @chmod($temporary, $mode & 0777);
            }
            if (!@rename($temporary, $this->file)) {
                return new WP_Error('pbv_drive_catalog_write', 'Nu s-a putut înlocui catalogul JSON.');
            }
            $temporary = '';
            return true;
        } finally {
            if ($temporary && file_exists($temporary)) {
                @unlink($temporary);
            }
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }
}
