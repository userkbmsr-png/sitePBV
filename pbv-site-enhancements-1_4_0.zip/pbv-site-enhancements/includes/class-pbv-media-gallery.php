<?php
/**
 * Tagged image and video gallery for the PBV site.
 *
 * @package PBV_Site_Enhancements
 */

if (!defined('ABSPATH')) {
    exit;
}

final class PBV_Media_Gallery {
    const TAXONOMY = 'pbv_media_tag';
    const PHOTO_SLUG = 'foto';
    const VERSION = '1.3.0';

    public function __construct() {
        add_action('init', array($this, 'register_taxonomy'), 0);
        add_action('init', array($this, 'ensure_photo_term'), 1);
        add_action('init', array($this, 'ensure_media_page'), 20);
        add_shortcode('pbv_media_gallery', array($this, 'render_gallery'));
        add_filter('wp_nav_menu_items', array($this, 'add_media_menu_item'), 20, 2);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
    }

    public function register_taxonomy() {
        if (taxonomy_exists(self::TAXONOMY)) {
            return;
        }

        $labels = array(
            'name' => 'Etichete media PBV',
            'singular_name' => 'Etichetă media PBV',
            'search_items' => 'Caută etichete media',
            'popular_items' => 'Etichete media frecvente',
            'all_items' => 'Toate etichetele media',
            'edit_item' => 'Editează eticheta media',
            'update_item' => 'Actualizează eticheta media',
            'add_new_item' => 'Adaugă etichetă media',
            'new_item_name' => 'Numele noii etichete media',
            'separate_items_with_commas' => 'Separați etichetele cu virgule',
            'add_or_remove_items' => 'Adăugați sau eliminați etichete media',
            'choose_from_most_used' => 'Alegeți dintre etichetele folosite frecvent',
            'menu_name' => 'Etichete media PBV',
        );

        register_taxonomy(self::TAXONOMY, array('attachment'), array(
            'labels' => $labels,
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'upload.php',
            'show_in_rest' => true,
            'show_admin_column' => true,
            'hierarchical' => false,
            'query_var' => false,
            'rewrite' => false,
            'meta_box_cb' => 'post_tags_meta_box',
        ));
    }

    public function ensure_photo_term() {
        if (!current_user_can('manage_options') || !taxonomy_exists(self::TAXONOMY) || term_exists(self::PHOTO_SLUG, self::TAXONOMY)) {
            return;
        }
        wp_insert_term('foto', self::TAXONOMY, array('slug' => self::PHOTO_SLUG));
    }

    /** Create the public page on first load/update, without overwriting existing page content. */
    public function ensure_media_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $page = get_page_by_path('media', OBJECT, 'page');
        if (!$page) {
            wp_insert_post(array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_title' => 'Media',
                'post_name' => 'media',
                'post_content' => '[pbv_media_gallery]',
            ));
            return;
        }

        if (trim((string) $page->post_content) === '') {
            wp_update_post(array(
                'ID' => (int) $page->ID,
                'post_content' => '[pbv_media_gallery]',
            ));
        }
    }

    /** Add a Media link to a configured primary WordPress menu if it is not already present. */
    public function add_media_menu_item($items, $args) {
        if (!is_object($args) || empty($args->theme_location) || $args->theme_location !== 'primary-menu') {
            return $items;
        }

        $page = get_page_by_path('media', OBJECT, 'page');
        if (!$page || $page->post_status !== 'publish') {
            return $items;
        }
        $url = get_permalink($page);
        $target_path = wp_parse_url($url, PHP_URL_PATH);
        if (!$url || !$target_path) {
            return $items;
        }

        if (preg_match_all('/<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1/is', (string) $items, $matches)) {
            foreach ($matches[2] as $href) {
                $href = html_entity_decode($href, ENT_QUOTES, get_bloginfo('charset') ? get_bloginfo('charset') : 'UTF-8');
                $existing_path = wp_parse_url($href, PHP_URL_PATH);
                if ($existing_path && untrailingslashit($existing_path) === untrailingslashit($target_path)) {
                    return $items;
                }
            }
        }

        return $items . '<li class="menu-item menu-item-type-post_type menu-item-object-page pbv-media-menu-item"><a href="' . esc_url($url) . '">Media</a></li>';
    }

    public function enqueue_assets() {
        if (!is_page('media')) {
            global $post;
            if (!($post instanceof WP_Post) || !has_shortcode($post->post_content, 'pbv_media_gallery')) {
                return;
            }
        }

        $plugin_url = plugin_dir_url(dirname(__DIR__) . '/pbv-site-enhancements.php');
        wp_enqueue_style('pbv-media-gallery', $plugin_url . 'assets/pbv-media-gallery.css', array(), self::VERSION);
        wp_enqueue_script('pbv-media-gallery', $plugin_url . 'assets/pbv-media-gallery.js', array(), self::VERSION, true);
    }

    private function is_local_upload($attachment_id, $uploads) {
        if (empty($uploads['basedir'])) {
            return false;
        }
        $base = realpath($uploads['basedir']);
        $file = get_attached_file($attachment_id);
        $real_file = $file ? realpath($file) : false;
        if ($base === false || $real_file === false || !is_file($real_file)) {
            return false;
        }

        $base = trailingslashit(wp_normalize_path($base));
        $real_file = wp_normalize_path($real_file);
        return strncasecmp($real_file, $base, strlen($base)) === 0;
    }

    public function render_gallery() {
        if (!taxonomy_exists(self::TAXONOMY)) {
            return '<p class="pbv-media-empty">Galeria media nu este disponibilă momentan.</p>';
        }

        $attachments = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'tax_query' => array(array(
                'taxonomy' => self::TAXONOMY,
                'field' => 'slug',
                'terms' => self::PHOTO_SLUG,
            )),
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ));

        $uploads = wp_upload_dir();
        $media = array();
        foreach ($attachments as $attachment) {
            $id = (int) $attachment->ID;
            $mime = (string) get_post_mime_type($id);
            $is_image = wp_attachment_is_image($id);
            $is_video = strpos($mime, 'video/') === 0;
            if ((!$is_image && !$is_video) || !$this->is_local_upload($id, $uploads)) {
                continue;
            }

            $url = wp_get_attachment_url($id);
            if (!$url) {
                continue;
            }

            $title = trim((string) get_the_title($id));
            if ($title === '') {
                $title = wp_basename(get_attached_file($id));
            }
            $alt = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
            if ($alt === '') {
                $alt = $title;
            }

            $media[] = array(
                'id' => $id,
                'mime' => $mime,
                'url' => $url,
                'title' => $title,
                'alt' => $alt,
                'is_image' => $is_image,
            );
        }

        if (!$media) {
            return '<p class="pbv-media-empty">Nu există încă imagini sau videoclipuri cu eticheta „foto”. Etichetați fișierele din Biblioteca media WordPress pentru a le afișa aici.</p>';
        }

        $image_count = 0;
        foreach ($media as $item) {
            if (!empty($item['is_image'])) {
                $image_count++;
            }
        }
        $gallery_id = function_exists('wp_unique_id') ? wp_unique_id('pbv-media-gallery-') : 'pbv-media-gallery-' . wp_rand(1000, 999999);
        $count = count($media);
        ob_start();
        ?>
        <section id="<?php echo esc_attr($gallery_id); ?>" class="pbv-media-gallery" role="region" aria-roledescription="carusel" aria-label="Galerie de fotografii și videoclipuri">
            <ol class="pbv-media-track" data-pbv-media-track>
                <?php foreach ($media as $index => $item) : ?>
                    <li class="pbv-media-slide" data-pbv-media-slide data-media-title="<?php echo esc_attr($item['title']); ?>">
                        <figure>
                            <div class="pbv-media-stage">
                                <?php if ($item['is_image']) : ?>
                                    <?php echo wp_get_attachment_image($item['id'], 'large', false, array(
                                        'class' => 'pbv-media-image',
                                        'alt' => $item['alt'],
                                        'loading' => 'lazy',
                                        'decoding' => 'async',
                                    )); ?>
                                <?php else : ?>
                                    <video class="pbv-media-video" controls playsinline preload="none" aria-label="Videoclip: <?php echo esc_attr($item['title']); ?>">
                                        <source src="<?php echo esc_url($item['url']); ?>" type="<?php echo esc_attr($item['mime']); ?>">
                                        <a href="<?php echo esc_url($item['url']); ?>">Deschide sau descarcă videoclipul</a>
                                    </video>
                                <?php endif; ?>
                            </div>
                            <figcaption><?php echo esc_html($item['title']); ?></figcaption>
                        </figure>
                    </li>
                <?php endforeach; ?>
            </ol>
            <?php if ($count > 1) : ?>
                <div class="pbv-media-controls" data-pbv-media-controls hidden>
                    <button type="button" class="pbv-media-control" data-pbv-media-prev aria-label="Elementul anterior">‹ <span>Anterior</span></button>
                    <div class="pbv-media-indicators" role="group" aria-label="Alegeți elementul din galerie">
                        <?php foreach ($media as $index => $item) : ?>
                            <button type="button" class="pbv-media-indicator" data-pbv-media-indicator="<?php echo (int) $index; ?>" aria-label="Afișează elementul <?php echo (int) ($index + 1); ?>: <?php echo esc_attr($item['title']); ?>" <?php echo $index === 0 ? 'aria-current="true"' : ''; ?>><span class="pbv-media-sr-only"><?php echo (int) ($index + 1); ?></span></button>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="pbv-media-control" data-pbv-media-next aria-label="Elementul următor"><span>Următorul</span> ›</button>
                </div>
                <p class="pbv-media-status pbv-media-sr-only" data-pbv-media-status aria-live="polite" aria-atomic="true"></p>
            <?php endif; ?>
            <?php if ($image_count > 0) : ?>
                <div class="pbv-media-thumbnail-rail" data-pbv-media-thumbnail-rail>
                    <h3 class="pbv-media-thumbnail-heading">Toate fotografiile etichetate „foto”</h3>
                    <div class="pbv-media-thumbnails" role="group" aria-label="Alegeți o fotografie din galeria foto" data-pbv-media-thumbnails>
                        <?php foreach ($media as $index => $item) : if (empty($item['is_image'])) { continue; } ?>
                            <button type="button" class="pbv-media-thumbnail" data-pbv-media-thumbnail="<?php echo (int) $index; ?>" aria-label="Afișează fotografia: <?php echo esc_attr($item['title']); ?>" aria-pressed="false" title="<?php echo esc_attr($item['title']); ?>">
                                <?php echo wp_get_attachment_image($item['id'], 'thumbnail', false, array(
                                    'class' => 'pbv-media-thumbnail-image',
                                    'alt' => '',
                                    'loading' => 'lazy',
                                    'decoding' => 'async',
                                )); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }
}
